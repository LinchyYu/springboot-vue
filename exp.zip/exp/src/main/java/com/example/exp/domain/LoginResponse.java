package com.example.exp.domain;

public class LoginResponse {
    private int code; // 200 for success, 401 for unauthorized, etc.
    private String msg; // Message to the client
    private String token; // Simulated token
    private String username; // Logged in username (this will be the user ID)
    private String nickname; // 新增字段：用户昵称

    public LoginResponse(int code, String msg, String token, String username, String nickname) {
        this.code = code;
        this.msg = msg;
        this.token = token;
        this.username = username;
        this.nickname = nickname;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }
} 