package com.example.exp.service;

import com.example.exp.domain.Comment;
import java.util.List;

public interface CommentService {
    Comment addComment(Comment comment);
    List<Comment> getCommentsByPostId(int postId);
    Comment deleteComment(int commentId);
    Comment updateComment(Comment comment);
    Comment findCommentById(int id);
}