package com.example.exp.controller;

import com.example.exp.domain.Comment;
import com.example.exp.service.CommentService;
import com.example.exp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/comments")
public class CommentController {

    private final CommentService commentService;
    private final UserService userService;

    @Autowired
    public CommentController(CommentService commentService, UserService userService) {
        this.commentService = commentService;
        this.userService = userService;
    }

    // 添加评论
    @PostMapping("/add-comment")
    public ResponseEntity<Comment> addComment(@RequestBody Comment newComment) {
        // 检查用户是否登录 (通过 res_id 查找用户)
        if (userService.findUserById(newComment.getRes_id()) == null) {
            return new ResponseEntity<>(HttpStatus.UNAUTHORIZED); // 如果用户未登录，返回401
        }
        try {
            Comment addedComment = commentService.addComment(newComment);
            return new ResponseEntity<>(addedComment, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 根据帖子ID获取所有评论
    @GetMapping("/post/{postId}")
    public ResponseEntity<List<Comment>> getCommentsByPostId(@PathVariable int postId) {
        try {
            List<Comment> comments = commentService.getCommentsByPostId(postId);
            return new ResponseEntity<>(comments, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 删除评论
    @DeleteMapping("/delete/{commentId}")
    public ResponseEntity<Comment> deleteComment(@PathVariable int commentId) {
        try {
            Comment deletedComment = commentService.deleteComment(commentId);
            return new ResponseEntity<>(deletedComment, HttpStatus.OK);
        } catch (RuntimeException e) {
            if (e.getMessage().equals("Comment not found")) {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    // 更新评论
    @PutMapping("/update/{commentId}")
    public ResponseEntity<Comment> updateComment(@PathVariable int commentId, @RequestBody Comment updatedComment) {
        try {
            updatedComment.setId(commentId); // 确保从路径变量获取到的ID设置到评论对象中
            Comment result = commentService.updateComment(updatedComment);
            return new ResponseEntity<>(result, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
} 