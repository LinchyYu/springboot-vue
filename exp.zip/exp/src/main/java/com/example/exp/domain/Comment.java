package com.example.exp.domain;

public class Comment {
    private int id;
    private String comment_content;
    private String comment_time;
    private int res_id; // 回复者id
    private String nickname; // 回复者昵称，用于显示
    private int com_id; // 暂时为空，先不管
    private int maincom_id; // 暂时为空，先不管
    private int post_id;

    public Comment() {
    }

    public Comment(int id, String comment_content, String comment_time, int res_id, String nickname, int com_id, int maincom_id, int post_id) {
        this.id = id;
        this.comment_content = comment_content;
        this.comment_time = comment_time;
        this.res_id = res_id;
        this.nickname = nickname;
        this.com_id = com_id;
        this.maincom_id = maincom_id;
        this.post_id = post_id;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getComment_content() {
        return comment_content;
    }

    public void setComment_content(String comment_content) {
        this.comment_content = comment_content;
    }

    public String getComment_time() {
        return comment_time;
    }

    public void setComment_time(String comment_time) {
        this.comment_time = comment_time;
    }

    public int getRes_id() {
        return res_id;
    }

    public void setRes_id(int res_id) {
        this.res_id = res_id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public int getCom_id() {
        return com_id;
    }

    public void setCom_id(int com_id) {
        this.com_id = com_id;
    }

    public int getMaincom_id() {
        return maincom_id;
    }

    public void setMaincom_id(int maincom_id) {
        this.maincom_id = maincom_id;
    }

    public int getPost_id() {
        return post_id;
    }

    public void setPost_id(int post_id) {
        this.post_id = post_id;
    }

    @Override
    public String toString() {
        return "Comment{" +
                "id=" + id +
                ", comment_content='" + comment_content + '\'' +
                ", comment_time='" + comment_time + '\'' +
                ", res_id=" + res_id +
                ", nickname='" + nickname + '\'' +
                ", com_id=" + com_id +
                ", maincom_id=" + maincom_id +
                ", post_id=" + post_id +
                '}';
    }
}