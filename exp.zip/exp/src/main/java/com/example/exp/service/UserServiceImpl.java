package com.example.exp.service;
import com.example.exp.domain.user;
import com.example.exp.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class UserServiceImpl implements UserService {
    private final UserMapper userMapper;
    @Autowired
    public UserServiceImpl(UserMapper userMapper) {
        this.userMapper = userMapper;
    }
    @Override
    public List<user> getAllUsers() {
        return userMapper.findAllUsers();
    }
    @Override
    public user findUserById(int id) {
        return userMapper.findUserById(id);
    }

    @Override
    public user addUser(user newUser) {
        // 保存用户到数据库
        int rowsAffected = userMapper.addUser(newUser);

        // 检查插入是否成功
        if (rowsAffected > 0) {
            // 查询新插入的用户数据
            return userMapper.findUserById(newUser.getId());
        } else {
            throw new RuntimeException("Failed to save user");
        }

    }

    @Override
    public user updateUser(user updatedUser) {
        int rowsAffected = userMapper.updateUser(updatedUser);
        if (rowsAffected > 0) {
            // 查询更新的用户数据
            return userMapper.findUserById(updatedUser.getId());
        } else {
            throw new RuntimeException("Failed to save user");
        }
    }

    @Override
    public user delUser(int id) {
        user del = userMapper.findUserById(id);
        int rowsAffected = userMapper.delUser(id);
        if (rowsAffected > 0) {
            // 查询更新的用户数据
            return del;
        } else {
            throw new RuntimeException("Failed to save user");
        }

    }

    @Override
    public user findByUsername(String username) {
        return userMapper.findByUsername(username);
    }
}