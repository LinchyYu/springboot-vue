<template>
  <div class="index-user-page">
    <div class="header-container">
      <button @click="goToHome" class="btn back-home-btn">返回首页</button>
      <h1 class="title">请选择功能</h1>
    </div>

    <!-- 登录表单 -->
    <div v-if="!isLoggedIn" class="login-section">
      <h2 class="subtitle">用户登录</h2>
      <form @submit.prevent="handleLogin" class="login-form">
        <div class="input-group">
          <label for="userId">用户ID:</label>
          <input type="number" id="userId" v-model="loginForm.userId" placeholder="请输入用户ID" required class="input-field">
        </div>
        <div class="input-group">
          <label for="password">密码:</label>
          <input type="password" id="password" v-model="loginForm.password" placeholder="请输入密码" required class="input-field">
        </div>
        <button type="submit" class="btn login-btn">登录</button>
      </form>
      <div v-if="loginSuccess" class="success-message">登录成功！欢迎 {{ loggedInUser }}</div>
      <div v-if="loginError" class="error-message">{{ loginError }}</div>
    </div>

    <div v-if="isLoggedIn" class="logged-in-info">
      <p>登录成功！欢迎 {{ loggedInUser }} :)</p>
      <button @click="logout" class="btn logout-btn">注销</button>
    </div><br>

    <div class="button-group">
      <button @click="goToAddPage" class="btn">前往注册用户</button>
      <button v-if="isLoggedIn" @click="goToDelPage" class="btn">前往注销用户</button>
      <button v-if="isLoggedIn" @click="goToUpdatePage" class="btn">前往更改信息</button>
      <button @click="goToSearPage" class="btn">前往查询用户</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'UserIndexPage',
  data() {
    return {
      loginForm: {
        userId: null,
        password: '',
      },
      loginSuccess: false,
      loginError: '',
      loggedInUser: '',
      isLoggedIn: false,
    };
  },
  mounted() {
    this.checkLoginStatus();
  },
  methods: {
    checkLoginStatus() {
      const userToken = localStorage.getItem('userToken');
      const nickname = localStorage.getItem('nickname');
      if (userToken && nickname) {
        this.isLoggedIn = true;
        this.loggedInUser = nickname;
        this.loginSuccess = true;
      } else {
        this.isLoggedIn = false;
        this.loggedInUser = '';
        this.loginSuccess = false;
      }
    },
    async handleLogin() {
      this.loginSuccess = false;
      this.loginError = '';
      this.loggedInUser = '';
      try {
        const response = await axios.post('http://localhost:8888/users/login', this.loginForm);
        if (response.data.code === 200) { 
          this.loginSuccess = true;
          this.loggedInUser = response.data.nickname;
          this.isLoggedIn = true;
          localStorage.setItem('userToken', response.data.token || 'dummy_token');
          localStorage.setItem('username', response.data.username);
          localStorage.setItem('nickname', response.data.nickname);
        } else {
          this.loginError = response.data.msg || '登录失败，请检查用户ID和密码。';
          this.isLoggedIn = false;
        }
      } catch (error) {
        this.loginError = '登录请求失败，请检查网络或后端。' + (error.response?.data?.msg || '');
        console.error('登录失败:', error);
        this.isLoggedIn = false;
      }
    },
    logout() {
      localStorage.removeItem('userToken');
      localStorage.removeItem('username');
      localStorage.removeItem('nickname');
      this.isLoggedIn = false;
      this.loggedInUser = '';
      this.loginSuccess = false;
      this.loginError = '';
      alert('您已成功注销。');
    },
    goToAddPage() {
      this.$router.push({ name: 'AddUser' });
    },
    goToDelPage() {
      this.$router.push({ name: 'DelUser' });
    },
    goToUpdatePage() {
      this.$router.push({ name: 'UpdateUser' });
    },
    goToSearPage() {
      this.$router.push({ name: 'SearPage' });
    },
    goToHome() {
      this.$router.push({ name: 'index' });
    }
  }
}
</script>

<style scoped>
.index-user-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  min-height: 100vh;
  background: #f5f5f5;
  color: #333;
  font-family: "Roboto", sans-serif;
  padding: 20px;
}

.header-container {
  width: 100%;
  max-width: 800px; 
  position: relative; 
  display: flex; 
  justify-content: center; 
  align-items: center;
  margin-bottom: 2rem;
}

.title {
  font-size: 2.5rem;
  margin-bottom: 0; 
  text-align: center;
  color: #333;
  text-shadow: none;
  font-weight: bold;
}

.subtitle {
  font-size: 1.8rem;
  margin-bottom: 1.5rem;
  color: #555;
}

.login-section {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 30px;
  margin-bottom: 30px;
  width: 100%;
  max-width: 400px;
  text-align: center;
}

.login-form {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.input-group {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.input-group label {
  margin-bottom: 5px;
  font-weight: bold;
  color: #333;
}

.input-field {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 1rem;
}

.input-field:focus {
  outline: none;
  border-color: #607d8b;
  box-shadow: 0 0 0 3px rgba(96, 125, 139, 0.3);
}

.button-group {
  display: flex; 
  flex-direction: column; 
  gap: 20px; 
  max-width: 600px;
  width: 100%;
  margin-bottom: 30px;
}

.btn {
  padding: 15px 30px;
  background: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1.2rem;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  text-shadow: none;
}

.btn:hover {
  background: #78909c;
  transform: scale(1.05);
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
}

.btn:active {
  transform: scale(0.95);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.login-btn {
  padding: 12px 25px;
  font-size: 1.1rem;
  align-self: center;
}

.back-home-btn {
  position: absolute; 
  left: 0; 
  top: 50%; 
  transform: translateY(-50%); 
  padding: 8px 16px;
  font-size: 14px;
  transition: background-color 0.3s;
  box-shadow: none;
}

.back-home-btn:hover {
  background-color: #78909c;
  transform: translateY(-50%);
  box-shadow: none;
}

.back-home-btn:active {
  transform: translateY(-50%);
  box-shadow: none;
}

.success-message {
  margin-top: 15px;
  padding: 10px;
  background-color: #e6ffe6;
  color: #4CAF50;
  border: 1px solid #4CAF50;
  border-radius: 4px;
}

.error-message {
  margin-top: 15px;
  padding: 10px;
  background-color: #ffe6e6;
  color: #f44336;
  border: 1px solid #f44336;
  border-radius: 4px;
}

.logged-in-info {
  margin-top: 20px;
  padding: 15px;
  background: #ffffff;
  border-radius: 8px;
  text-align: center;
  color: #333;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
}

.logged-in-info p {
  margin: 0;
  font-size: 1.1rem;
  font-weight: bold;
}

.logout-btn {
  padding: 8px 16px;
  background-color: #f44336;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
}

.logout-btn:hover {
  background-color: #d32f2f;
  transform: scale(1.02);
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.logout-btn:active {
  transform: scale(0.98);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}
</style>