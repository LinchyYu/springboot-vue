<!--<template>-->
<!--  <div>-->
<!--    <h1>{{ message1 }}</h1>-->
<!--    <div>-->
<!--      <input type="number" v-model="sear_id" placeholder="输入id" />-->
<!--      <button @click="search">查询</button>-->
<!--      <div v-if="olduser !== null">-->
<!--        <p>查询成功！您的信息如下：</p>-->
<!--        <p><strong>ID:</strong> {{ olduser.id }}</p>-->
<!--        <p><strong>Name:</strong> {{ olduser.nickname }}</p>-->
<!--        <p><strong>Signup_date:</strong> {{ olduser.signup_date }}</p>-->
<!--        <p><strong>Level:</strong> {{ olduser.level }}</p>-->
<!--        <p><strong>Introduction:</strong>{{ olduser.introduction }}</p>-->
<!--        <p><strong>Email:</strong>{{ olduser.email }}</p>-->
<!--      </div>-->
<!--      <div v-else>-->
<!--        <p>请输入查询用户id...</p>-->
<!--      </div>-->
<!--    </div>-->

<!--    <h1>{{ message2 }}</h1>-->
<!--    <div>-->
<!--      <input type="text" v-model="user.nickname" placeholder="输入新昵称" />-->
<!--      <input type="text" v-model="user.password" placeholder="输入新密码" />-->
<!--      <input type="text" v-model="user.introduction" placeholder="输入新简介" />-->
<!--      <input type="text" v-model="user.email" placeholder="输入新邮箱" />-->
<!--      <select v-model="user.gender">-->
<!--        <option value="男">男</option>-->
<!--        <option value="女">女</option>-->
<!--        <option value="">保密</option>-->
<!--      </select>-->
<!--    </div><br>-->

<!--    <button @click="update">更改</button>-->
<!--    <div v-if="newuser !== null">-->
<!--      <p>更改成功！新信息如下：</p>-->
<!--      <div>-->
<!--        <p><strong>ID:</strong> {{ newuser.id }}</p>-->
<!--        <p><strong>Name:</strong> {{ newuser.nickname }}</p>-->
<!--        <p><strong>Signup_date:</strong> {{ newuser.signup_date }}</p>-->
<!--        <p><strong>Level:</strong> {{ newuser.level }}</p>-->
<!--        <p><strong>Introduction:</strong>{{ newuser.introduction }}</p>-->
<!--        <p><strong>Email:</strong>{{ newuser.email }}</p>-->
<!--        <p><strong>Gender:</strong>{{ newuser.gender }}</p>-->
<!--      </div>-->
<!--    </div>-->
<!--  </div>-->
<!--</template>-->

<!--<script>-->
<!--import axios from 'axios';-->
<!--import HelloWorld from "@/components/HelloWorld.vue";-->

<!--export default {-->
<!--  components: {HelloWorld},-->
<!--  data() {-->
<!--    return {-->
<!--      message1: "更新信息",-->
<!--      message2: "输入要更新的信息",-->
<!--      sear_id: 0,-->
<!--      user: {-->
<!--        id: 0,-->
<!--        nickname: null,-->
<!--        password: null,-->
<!--        introduction: null,-->
<!--        email: null,-->
<!--        gender: null,-->
<!--      },      // 用户信息-->
<!--      olduser: null,-->
<!--      newuser: null-->
<!--    };-->
<!--  },-->
<!--  methods: {-->
<!--    async search() {-->
<!--      try {-->
<!--        const response = await axios.get(`http://localhost:8888/users/get/${this.sear_id}`); // 向后端请求数据-->
<!--        this.olduser = response.data;-->
<!--      } catch (error) {-->
<!--        console.error('Error fetching user data:', error);-->
<!--      }-->
<!--    },-->
<!--    async update() {-->
<!--      try {-->
<!--        if (this.user.gender === "") {-->
<!--          this.user.gender = null;-->
<!--        }-->
<!--        this.user.id = this.sear_id;-->
<!--        if (this.user.nickname === null) {-->
<!--          this.user.nickname = this.olduser.nickname;-->
<!--        }-->
<!--        if (this.user.password === null) {-->
<!--          this.user.password = this.olduser.password;-->
<!--        }-->
<!--        if (this.user.introduction === null) {-->
<!--          this.user.introduction = this.olduser.introduction;-->
<!--        }-->
<!--        if (this.user.email === null) {-->
<!--          this.user.email = this.olduser.email;-->
<!--        }-->
<!--        if (this.user.gender === null) {-->
<!--          this.user.gender = this.olduser.gender;-->
<!--        }-->
<!--        console.log("Sending data to backend:", this.user);-->
<!--        // 发送请求到后端添加用户-->
<!--        const response = await axios.post(`http://localhost:8888/users/update-user`, this.user);-->
<!--        // 获取新用户信息-->
<!--        this.newuser = response.data;-->
<!--      } catch (error) {-->
<!--        console.error("请求失败：", error);-->
<!--      }-->
<!--    }-->
<!--  }-->
<!--}-->
<!--</script>-->
<!--<style>-->
<!--</style>-->

<template>
  <div class="update-page">
    <h1 class="title">{{ message1 }}</h1>
    <div class="search-group">
      <input type="number" v-model="sear_id" placeholder="输入id" class="input-field" />
      <button @click="search" class="btn">查询</button>
      <div v-if="olduser && olduser.id" class="info-message">
        <p>查询成功！您的信息如下：</p>
        <p><strong>ID:</strong> {{ olduser.id }}</p>
        <p><strong>昵称:</strong> {{ olduser.nickname }}</p>
        <p><strong>注册日期:</strong> {{ olduser.signup_date }}</p>
        <p><strong>等级:</strong> {{ olduser.level }}</p>
        <p><strong>简介:</strong>{{ olduser.introduction }}</p>
        <p><strong>邮箱:</strong>{{ olduser.email }}</p>
      </div>
      <div v-else-if="searchError" class="error-message">
        <p>用户不存在！</p>
      </div>
      <div v-else>
        <p class="info-message">请输入查询用户id...</p>
      </div>
    </div>

    <template v-if="olduser && olduser.id">
      <h1 class="title">{{ message2 }}</h1>
      <div class="update-group">
        <input type="text" v-model="user.nickname" placeholder="输入新昵称" class="input-field" />
        <input type="password" v-model="user.password" placeholder="输入新密码" class="input-field" />
        <input type="text" v-model="user.introduction" placeholder="输入新简介" class="input-field" />
        <input type="email" v-model="user.email" placeholder="输入新邮箱" class="input-field" />
        <select v-model="user.gender" class="input-field">
          <option value="男">男</option>
          <option value="女">女</option>
          <option value="">保密</option>
        </select>
      </div>
      <button @click="update" class="btn">更改</button>
      <div v-if="newuser !== null" class="success-message">
        <p>更改成功！新信息如下：</p>
        <div>
          <p><strong>ID:</strong> {{ newuser.id }}</p>
          <p><strong>昵称:</strong> {{ newuser.nickname }}</p>
          <p><strong>注册日期:</strong> {{ newuser.signup_date }}</p>
          <p><strong>等级:</strong> {{ newuser.level }}</p>
          <p><strong>简介:</strong>{{ newuser.introduction }}</p>
          <p><strong>邮箱:</strong>{{ newuser.email }}</p>
          <p><strong>性别:</strong>{{ newuser.gender }}</p>
        </div>
      </div>
    </template>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      message1: "更新信息",
      message2: "输入要更新的信息",
      sear_id: null,
      user: {
        id: null,
        nickname: null,
        password: null,
        introduction: null,
        email: null,
        gender: null,
      },      // 用户信息
      olduser: null,
      newuser: null
    };
  },
  methods: {
    async search() {
      try {
        if (!this.sear_id) {
          this.olduser = null;
          return;
        }
        const response = await axios.get(`http://localhost:8888/users/get/${this.sear_id}`); // 向后端请求数据
        this.olduser = response.data;
      } catch (error) {
        console.error('Error fetching user data:', error);
        this.olduser = null;
      }
    },
    async update() {
      try {
        if (this.user.gender === "") {
          this.user.gender = null;
        }
        this.user.id = this.sear_id;
        if (!this.user.nickname) {
          this.user.nickname = this.olduser.nickname;
        }
        if (!this.user.password) {
          this.user.password = this.olduser.password;
        }
        if (!this.user.introduction) {
          this.user.introduction = this.olduser.introduction;
        }
        if (!this.user.email) {
          this.user.email = this.olduser.email;
        }
        if (this.user.gender === null) {
          this.user.gender = this.olduser.gender;
        }
        console.log("Sending data to backend:", this.user);
        const response = await axios.post(`http://localhost:8888/users/update-user`, this.user);
        this.newuser = response.data;
      } catch (error) {
        console.error("请求失败：", error);
      }
    }
  }
}
</script>

<style scoped>
.update-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #f5f5f5; /* 统一为 PostDetail.vue 的背景色 */
  color: #333; /* 统一为主要文本颜色 */
  font-family: "Roboto", sans-serif;
  padding: 20px;
}

.title {
  font-size: 2.5rem;
  margin-bottom: 2rem;
  text-align: center;
  color: #333; /* 统一为主要文本颜色 */
  text-shadow: none; /* 移除阴影 */
  font-weight: bold;
}

.search-group, .update-group {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  max-width: 400px;
  margin-bottom: 2rem;
}

.input-field {
  width: 100%;
  padding: 10px;
  margin-bottom: 1rem;
  background: white; /* 统一为 PostDetail.vue 的卡片背景色 */
  color: #333; /* 统一为主要文本颜色 */
  border: 1px solid #eee; /* 添加边框 */
  border-radius: 4px; /* 统一为 4px */
  font-size: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 统一为轻微阴影 */
}

.input-field:focus {
  outline: none;
  border-color: #607d8b; /* 统一为按钮默认色 */
  box-shadow: 0 0 0 2px rgba(96, 125, 139, 0.3); /* 统一为按钮默认色系的 focus 阴影 */
}

.btn {
  padding: 15px 30px;
  background: #607d8b; /* 统一为 PostDetail.vue 的按钮颜色 */
  color: white;
  border: none;
  border-radius: 4px; /* 统一为 4px */
  font-size: 1.2rem;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  text-shadow: none; /* 移除阴影 */
}

.btn:hover {
  background: #78909c; /* 统一为 PostDetail.vue 的按钮 hover 颜色 */
  transform: scale(1.05);
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
}

.btn:active {
  transform: scale(0.95);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.info-message, .success-message {
  margin-top: 1rem;
  padding: 1rem;
  background: white; /* 统一为 PostDetail.vue 的卡片背景色 */
  border-radius: 8px; /* 统一为 8px */
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1); /* 统一为 PostDetail.vue 的卡片阴影 */
  text-align: center;
  color: #333; /* 统一为主要文本颜色 */
}
</style>