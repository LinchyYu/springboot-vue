<!--<template>-->
<!--  <div>-->
<!--    <h1>{{ message1 }}</h1>-->
<!--    <div>-->
<!--      <input type="number" v-model="sear_id" placeholder="输入id" />-->
<!--      <button @click="search">查询</button>-->
<!--      <div v-if="searuser !== null">-->
<!--        <p>查询成功！您的信息如下：</p>-->
<!--        <p><strong>ID:</strong> {{ searuser.id }}</p>-->
<!--        <p><strong>Name:</strong> {{ searuser.nickname }}</p>-->
<!--        <p><strong>Signup_date:</strong> {{ searuser.signup_date }}</p>-->
<!--        <p><strong>Level:</strong> {{ searuser.level }}</p>-->
<!--        <p><strong>Introduction:</strong>{{ searuser.introduction }}</p>-->
<!--        <p><strong>Email:</strong>{{ searuser.email }}</p>-->
<!--      </div>-->
<!--      <div v-else-if="searchError">-->
<!--        <p>用户不存在！</p>-->
<!--      </div>-->
<!--      <div v-else>-->
<!--        <p>请输入查询用户id...</p>-->
<!--      </div>-->
<!--    </div>-->

<!--  </div>-->
<!--</template>-->

<!--<script>-->
<!--import axios from 'axios';-->
<!--import HelloWorld from "@/components/HelloWorld.vue";-->

<!--export default {-->
<!--  components: {HelloWorld},-->
<!--  data() {-->
<!--    return {-->
<!--      message1: "查询用户信息",-->
<!--      sear_id: 0,-->
<!--      // 用户信息-->
<!--      searuser: null,-->
<!--      searchError: null-->
<!--    };-->
<!--  },-->
<!--  methods: {-->
<!--    async search() {-->
<!--      try {-->
<!--        const response = await axios.get(`http://localhost:8888/users/get/${this.sear_id}`); // 向后端请求数据-->
<!--        if (response.status === 500) {-->
<!--          alert("用户不存在，查找失败！");-->
<!--          this.searchError = "用户不存在";-->
<!--          this.searuser = null;-->
<!--        } else {-->
<!--          this.searuser = response.data;-->
<!--        }-->
<!--      } catch (error) {-->
<!--        console.error('Error fetching user data:', error);-->
<!--      }-->
<!--    }-->
<!--  }-->
<!--}-->
<!--</script>-->
<!--<style>-->
<!--</style>-->
<template>
  <div class="search-page">
    <h1 class="title">{{ message1 }}</h1>
    <div class="search-group">
      <input type="number" v-model="sear_id" placeholder="输入id" class="input-field" />
      <button @click="search" class="btn">查询</button>
      <div v-if="searuser && searuser.id" class="result-message">
        <p>查询成功！您的信息如下：</p>
        <p><strong>ID:</strong> {{ searuser.id }}</p>
        <p><strong>昵称:</strong> {{ searuser.nickname }}</p>
        <p><strong>注册日期:</strong> {{ searuser.signup_date }}</p>
        <p><strong>等级:</strong> {{ searuser.level }}</p>
        <p><strong>简介:</strong>{{ searuser.introduction }}</p>
        <p><strong>邮箱:</strong>{{ searuser.email }}</p>
      </div>
      <div v-else-if="searchError">
        <p class="error-message">用户不存在！</p>
      </div>
      <div v-else>
        <p class="info-message">请输入查询用户id...</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      message1: "查询用户信息",
      sear_id: null,
      searuser: null,
      searchError: null
    };
  },
  methods: {
    async search() {
      try {
        if (!this.sear_id) {
          this.searchError = "请输入用户ID";
          return;
        }
        const response = await axios.get(`http://localhost:8888/users/get/${this.sear_id}`);
        if (response.status === 500 || !response.data || !response.data.id) {
          this.searchError = "用户不存在";
          this.searuser = null;
        } else {
          this.searuser = response.data;
          this.searchError = null;
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        this.searchError = "查询出错";
        this.searuser = null;
      }
    }
  }
}
</script>

<style scoped>
.search-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #f5f5f5;
  color: #333;
  font-family: "Roboto", sans-serif;
  padding: 20px;
}

.title {
  font-size: 2.5rem;
  margin-bottom: 2rem;
  text-align: center;
  color: #333;
  text-shadow: none;
  font-weight: bold;
}

.search-group {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  max-width: 400px;
}

.input-field {
  width: 100%;
  padding: 10px;
  margin-bottom: 1rem;
  background: white;
  color: #333;
  border: 1px solid #eee;
  border-radius: 4px;
  font-size: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.input-field:focus {
  outline: none;
  border-color: #607d8b;
  box-shadow: 0 0 0 2px rgba(96, 125, 139, 0.3);
}

.btn {
  padding: 15px 30px;
  background: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1.2rem;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  text-shadow: none;
}

.btn:hover {
  background: #78909c;
  transform: scale(1.05);
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
}

.btn:active {
  transform: scale(0.95);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.result-message, .error-message, .info-message {
  margin-top: 1rem;
  padding: 1rem;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  text-align: center;
  color: #333;
}

.error-message {
  color: #ff4d4d;
}

.info-message {
  color: #777;
}
</style>