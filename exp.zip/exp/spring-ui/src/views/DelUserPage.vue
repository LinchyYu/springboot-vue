<!--<template>-->
<!--  <div>-->
<!--    <h1>{{ message1 }}</h1>-->
<!--    <div>-->
<!--      <input type="number" v-model="sear_id" placeholder="输入id" />-->
<!--      <button @click="search">查询</button>-->
<!--      <div v-if="olduser !== null">-->
<!--        <p>查询成功！您的信息如下：</p>-->
<!--        <p><strong>ID:</strong> {{ olduser.id }}</p>-->
<!--        <p><strong>Name:</strong> {{ olduser.nickname }}</p>-->
<!--        <p><strong>Signup_date:</strong> {{ olduser.signup_date }}</p>-->
<!--        <p><strong>Level:</strong> {{ olduser.level }}</p>-->
<!--        <p><strong>Introduction:</strong>{{ olduser.introduction }}</p>-->
<!--        <p><strong>Email:</strong>{{ olduser.email }}</p>-->
<!--      </div>-->
<!--      <div v-else-if="searchError">-->
<!--        <p>用户不存在！</p>-->
<!--      </div>-->
<!--      <div v-else>-->
<!--        <p>请输入查询用户id...</p>-->
<!--      </div>-->
<!--    </div>-->

<!--    <h1>{{ message2 }}</h1>-->
<!--    <button @click="del">删除</button>-->
<!--    <div v-if="newuser !== null">-->
<!--      <p>删除成功！</p>-->
<!--&lt;!&ndash;      <div>&ndash;&gt;-->
<!--&lt;!&ndash;        <p><strong>ID:</strong> {{ newuser.id }}</p>&ndash;&gt;-->
<!--&lt;!&ndash;        <p><strong>Name:</strong> {{ newuser.nickname }}</p>&ndash;&gt;-->
<!--&lt;!&ndash;        <p><strong>Signup_date:</strong> {{ newuser.signup_date }}</p>&ndash;&gt;-->
<!--&lt;!&ndash;        <p><strong>Level:</strong> {{ newuser.level }}</p>&ndash;&gt;-->
<!--&lt;!&ndash;        <p><strong>Introduction:</strong>{{ newuser.introduction }}</p>&ndash;&gt;-->
<!--&lt;!&ndash;        <p><strong>Email:</strong>{{ newuser.email }}</p>&ndash;&gt;-->
<!--&lt;!&ndash;        <p><strong>Gender:</strong>{{ newuser.gender }}</p>&ndash;&gt;-->
<!--&lt;!&ndash;      </div>&ndash;&gt;-->
<!--    </div>-->
<!--  </div>-->
<!--</template>-->

<!--<script>-->
<!--import axios from 'axios';-->
<!--import HelloWorld from "@/components/HelloWorld.vue";-->

<!--export default {-->
<!--  components: {HelloWorld},-->
<!--  data() {-->
<!--    return {-->
<!--      message1: "删除信息",-->
<!--      message2: "是否删除",-->
<!--      sear_id: 0,-->
<!--       // 用户信息-->
<!--      olduser: null,-->
<!--      newuser: null,-->
<!--      searchError: null-->
<!--    };-->
<!--  },-->
<!--  methods: {-->
<!--    async search() {-->
<!--      try {-->
<!--        const response = await axios.get(`http://localhost:8888/users/get/${this.sear_id}`); // 向后端请求数据-->
<!--        if (response.status === 500) {-->
<!--          alert("用户不存在，删除失败！");-->
<!--          this.searchError = "用户不存在";-->
<!--          this.olduser = null;-->
<!--        } else {-->
<!--          this.olduser = response.data;-->
<!--        }-->
<!--      } catch (error) {-->
<!--        console.error('Error fetching user data:', error);-->
<!--      }-->
<!--    },-->
<!--    async del() {-->
<!--      try {-->

<!--        console.log("Sending data to backend:", this.user);-->
<!--        // 发送请求到后端添加用户-->
<!--        const response = await axios.get(`http://localhost:8888/users/del-user/${this.sear_id}`);-->
<!--        // 获取新用户信息-->
<!--        this.newuser = response.data;-->
<!--      } catch (error) {-->
<!--        console.error("请求失败：", error);-->
<!--      }-->
<!--    }-->
<!--  }-->
<!--}-->
<!--</script>-->
<!--<style>-->
<!--</style>-->

<template>
  <div class="user-management">
    <h1 class="title">{{ message1 }}</h1>
    <div class="search-group">
      <input type="number" v-model="sear_id" placeholder="输入id" class="input-field" />
      <button @click="search" class="btn">查询</button>
      <div v-if="olduser && olduser.id" class="result-message">
        <p>查询成功！您的信息如下：</p>
        <p><strong>ID:</strong> {{ olduser.id }}</p>
        <p><strong>昵称:</strong> {{ olduser.nickname }}</p>
        <p><strong>注册日期:</strong> {{ olduser.signup_date }}</p>
        <p><strong>等级:</strong> {{ olduser.level }}</p>
        <p><strong>简介:</strong>{{ olduser.introduction }}</p>
        <p><strong>邮箱:</strong>{{ olduser.email }}</p>
      </div>
      <div v-else-if="searchError">
        <p class="error-message">用户不存在！</p>
      </div>
      <div v-else>
        <p class="info-message">请输入查询用户id...</p>
      </div>
    </div>

    <template v-if="olduser && olduser.id">
      <h1 class="title">{{ message2 }}</h1>
      <div class="delete-group">
        <button @click="del" class="btn">删除</button>
        <div v-if="newuser !== null" class="result-message">
          <p>删除成功！</p>
        </div>
      </div>
    </template>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      message1: "查询用户信息",
      message2: "删除用户",
      sear_id: 0,
      olduser: null,
      newuser: null,
      searchError: null
    };
  },
  methods: {
    async search() {
      try {
        const response = await axios.get(`http://localhost:8888/users/get/${this.sear_id}`);
        if (response.status === 500) {
          this.searchError = "用户不存在";
          this.olduser = null;
        } else {
          this.olduser = response.data;
          this.searchError = null;
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    },
    async del() {
      try {
        const response = await axios.get(`http://localhost:8888/users/del-user/${this.sear_id}`);
        this.newuser = response.data;
      } catch (error) {
        console.error("请求失败：", error);
      }
    }
  }
}
</script>

<style scoped>
.user-management {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #f5f5f5;
  color: #333;
  font-family: "Roboto", sans-serif;
  padding: 20px;
}

.title {
  font-size: 2.5rem;
  margin-bottom: 1.5rem;
  text-align: center;
  color: #333;
  text-shadow: none;
  font-weight: bold;
}

.search-group, .delete-group {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  max-width: 400px;
  margin-bottom: 2rem;
}

.input-field {
  width: 100%;
  padding: 10px;
  margin-bottom: 1rem;
  background: white;
  color: #333;
  border: 1px solid #eee;
  border-radius: 4px;
  font-size: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.input-field:focus {
  outline: none;
  border-color: #607d8b;
  box-shadow: 0 0 0 2px rgba(96, 125, 139, 0.3);
}

.btn {
  padding: 15px 30px;
  background: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1.2rem;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  text-shadow: none;
}

.btn:hover {
  background: #78909c;
  transform: scale(1.05);
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
}

.btn:active {
  transform: scale(0.95);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.result-message, .error-message, .info-message {
  margin-top: 1rem;
  padding: 1rem;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  text-align: center;
  color: #333;
}

.error-message {
  color: #ff4d4d;
}

.info-message {
  color: #777;
}
</style>