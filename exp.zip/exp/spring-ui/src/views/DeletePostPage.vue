<template>
  <div class="delete-post-container">
    <h2 class="main-page-title">删除帖子</h2>
    
    <div class="main-content-wrapper">
      <div class="top-bar-aligned">
        <button @click="goBack" class="back-btn">返回详情页</button>
      </div>
      
      <div class="delete-confirmation">
        <p>您确定要删除这个帖子吗？此操作不可撤销。</p>
        <div class="button-group">
          <button @click="confirmDelete" class="btn delete-btn">确认删除</button>
          <button @click="goBack" class="btn cancel-btn">取消</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'DeletePostPage',
  methods: {
    async confirmDelete() {
      if (confirm('再次确认：您确定要删除这个帖子吗？')) {
        try {
          const id = this.$route.params.id
          await axios.delete(`http://localhost:8888/posts/delete/${id}`)
          alert('帖子删除成功！')
          this.$router.push({ name: 'index' })
        } catch (error) {
          console.error('删除帖子失败:', error)
          alert('删除帖子失败，请稍后重试')
        }
      }
    },
    goBack() {
      this.$router.push({ name: 'PostDetail', params: { id: this.$route.params.id } })
    }
  }
}
</script>

<style scoped>
.delete-post-container {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.main-page-title {
  text-align: center;
  color: #333;
  margin-bottom: 30px;
  font-size: 2em;
}

.main-content-wrapper {
  width: 100%;
  max-width: 800px;
}

.top-bar-aligned {
  margin-bottom: 20px;
  display: flex;
  justify-content: flex-start;
}

.back-btn {
  padding: 8px 16px;
  background-color: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
}

.back-btn:hover {
  background-color: #78909c;
}

.delete-confirmation {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 30px;
  width: 100%;
  text-align: center;
}

.button-group {
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-top: 20px;
}

.delete-btn {
  padding: 12px 25px;
  background-color: #f44336;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1.1rem;
  transition: background-color 0.3s;
}

.delete-btn:hover {
  background-color: #d32f2f;
}

.cancel-btn {
  padding: 12px 25px;
  background-color: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1.1rem;
  transition: background-color 0.3s;
}

.cancel-btn:hover {
  background-color: #78909c;
}
</style> 