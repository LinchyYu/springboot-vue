<!--<template>-->
<!--  <div>-->
<!--    <h1>{{ message }}</h1>-->
<!--    <input type="text" v-model="user.nickname" placeholder="输入昵称" /><br><br>-->
<!--    <input type="text" v-model="user.password" placeholder="输入密码" /><br><br>-->
<!--    <input type="text" v-model="user.introduction" placeholder="输入简介" /><br><br>-->
<!--    <input type="text" v-model="user.email" placeholder="输入邮箱" /><br><br>-->
<!--    <select v-model="user.gender">-->
<!--      <option value="男">男</option>-->
<!--      <option value="女">女</option>-->
<!--      <option value="null">保密</option>-->
<!--    </select><br><br>-->

<!--    <button @click="add">注册</button>-->
<!--    <div v-if="newuser !== null">-->
<!--      <p >注册成功！信息如下：</p>-->
<!--      <p><strong>ID:</strong> {{ newuser.id }}</p>-->
<!--      <p><strong>Name:</strong> {{ newuser.nickname }}</p>-->
<!--      <p><strong>Signup_date:</strong> {{ newuser.signup_date }}</p>-->
<!--      <p><strong>Level:</strong> {{ newuser.level }}</p>-->
<!--      <p><strong>Introduction:</strong>{{ newuser.introduction }}</p>-->
<!--      <p><strong>Email:</strong>{{ newuser.email }}</p>-->
<!--      <p><strong>Gender:</strong>{{ newuser.gender }}</p>-->

<!--    </div>-->

<!--  </div>-->
<!--</template>-->
<!--<script>-->
<!--import axios from 'axios';-->
<!--import HelloWorld from "@/components/HelloWorld.vue";-->
<!--export default {-->
<!--  components: {HelloWorld},-->
<!--  data() {-->
<!--    return {-->
<!--      message: "添加用户",-->
<!--      user: {-->
<!--        nickname: null,-->
<!--        password: null,-->
<!--        introduction: null,-->
<!--        email: null,-->
<!--        gender: null,-->
<!--        signup_date: null,-->
<!--        level: null-->
<!--      },      // 用户信息-->
<!--      newuser: null-->
<!--    };-->
<!--  },-->
<!--  methods: {-->
<!--    async add() {-->
<!--      try {-->
<!--        if (this.user.gender === "null") {-->
<!--          this.user.gender = null;-->
<!--        }-->
<!--        console.log("Sending data to backend:", this.user);-->
<!--        // 发送请求到后端添加用户-->
<!--        const response = await axios.post('http://localhost:8888/users/add-user', this.user);-->
<!--        // 获取新用户信息-->
<!--        this.newuser = response.data;-->
<!--      } catch (error) {-->
<!--        console.error("请求失败：", error);-->
<!--      }-->
<!--    }-->
<!--  }-->
<!--}-->
<!--</script>-->
<!--<style>-->
<!--</style>-->

<template>
  <div class="register-page">
    <h1 class="title">{{ message }}</h1>
    <form class="form-group" @submit.prevent="add"> <!-- 添加 @submit.prevent -->
      <div class="input-group">
        <label for="nickname">昵称</label>
        <input type="text" v-model="user.nickname" placeholder="输入昵称" id="nickname" />
      </div>
      <div class="input-group">
        <label for="password">密码</label>
        <input type="password" v-model="user.password" placeholder="输入密码" id="password" />
      </div>
      <div class="input-group">
        <label for="introduction">简介</label>
        <input type="text" v-model="user.introduction" placeholder="输入简介" id="introduction" />
      </div>
      <div class="input-group">
        <label for="email">邮箱</label>
        <input type="email" v-model="user.email" placeholder="输入邮箱" id="email" />
      </div>
      <div class="input-group">
        <label for="gender">性别</label>
        <select v-model="user.gender" id="gender" class="select">
          <option value="男">男</option>
          <option value="女">女</option>
          <option value="null">保密</option>
        </select>
      </div>
      <div class="button-group">
        <button type="submit" class="btn">注册</button> <!-- 添加 type="submit" -->
      </div>
    </form>
    <div v-if="newuser !== null" class="success-message">
      <p>注册成功！信息如下：</p>
      <p><strong>ID:</strong> {{ newuser.id }}</p>
      <p><strong>昵称:</strong> {{ newuser.nickname }}</p>
      <p><strong>注册日期:</strong> {{ newuser.signup_date }}</p>
      <p><strong>等级:</strong> {{ newuser.level }}</p>
      <p><strong>简介:</strong> {{ newuser.introduction }}</p>
      <p><strong>邮箱:</strong> {{ newuser.email }}</p>
      <p><strong>性别:</strong> {{ newuser.gender }}</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      message: "添加用户",
      user: {
        nickname: null,
        password: null,
        introduction: null,
        email: null,
        gender: null,
        signup_date: null,
        level: null
      },
      newuser: null
    };
  },
  methods: {
    async add(event) { // 添加 event 参数
      event.preventDefault(); // 阻止表单默认提交行为
      try {
        if (this.user.gender === "null") {
          this.user.gender = null;
        }
        console.log("Sending data to backend:", this.user);
        const response = await axios.post('http://localhost:8888/users/add-user', this.user);
        this.newuser = response.data;
      } catch (error) {
        console.error("请求失败：", error);
      }
    }
  }
}
</script>

<style scoped>
.register-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #f5f5f5; /* 统一为 PostDetail.vue 的背景色 */
  color: #333; /* 统一为主要文本颜色 */
  font-family: "Roboto", sans-serif;
  padding: 20px;
}

.title {
  font-size: 2.5rem;
  margin-bottom: 2rem;
  text-align: center;
  color: #333; /* 统一为主要文本颜色 */
  text-shadow: none; /* 移除阴影 */
  font-weight: bold;
}

.form-group {
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 400px;
}

.input-group {
  margin-bottom: 1rem;
}

.input-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-size: 1rem;
  color: #333; /* 统一为主要文本颜色 */
}

.input-group input,
.input-group select {
  width: 100%;
  padding: 10px;
  background: white; /* 统一为 PostDetail.vue 的卡片背景色 */
  color: #333; /* 统一为主要文本颜色 */
  border: 1px solid #eee; /* 添加边框 */
  border-radius: 4px; /* 统一为 4px */
  font-size: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 统一为轻微阴影 */
}

.input-group input:focus,
.input-group select:focus {
  outline: none;
  border-color: #607d8b; /* 统一为按钮默认色 */
  box-shadow: 0 0 0 2px rgba(96, 125, 139, 0.3); /* 统一为按钮默认色系的 focus 阴影 */
}

.select {
  background-color: white; /* 统一为 PostDetail.vue 的卡片背景色 */
  color: #333; /* 统一为主要文本颜色 */
  border: 1px solid #eee;
}

.select option {
  background-color: white; /* 选项背景色 */
  color: #333; /* 选项文字 */
}

.button-group {
  display: flex;
  justify-content: center;
}

.btn {
  padding: 15px 30px;
  background: #607d8b; /* 统一为 PostDetail.vue 的按钮颜色 */
  color: white;
  border: none;
  border-radius: 4px; /* 统一为 4px */
  font-size: 1.2rem;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  text-shadow: none; /* 移除阴影 */
}

.btn:hover {
  background: #78909c; /* 统一为 PostDetail.vue 的按钮 hover 颜色 */
  transform: scale(1.05);
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
}

.btn:active {
  transform: scale(0.95);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.success-message {
  margin-top: 2rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.1);
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  text-align: center;
}

.success-message p {
  margin: 0.5rem 0;
  font-size: 1rem;
  color: #78909c;
}
</style>