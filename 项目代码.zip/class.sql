-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: localhost    Database: class
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `bsinfo`
--

DROP TABLE IF EXISTS `bsinfo`;
/*!50001 DROP VIEW IF EXISTS `bsinfo`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `bsinfo` AS SELECT 
 1 AS `id`,
 1 AS `nickname`,
 1 AS `introduction`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int unsigned NOT NULL COMMENT '分区id',
  `cate_name` varchar(10) NOT NULL COMMENT '分区名',
  `admin_id` int unsigned NOT NULL COMMENT '管理员id',
  `message_num` int unsigned DEFAULT '0' COMMENT '新消息数',
  `hit` int unsigned DEFAULT '0' COMMENT '点击数',
  `post_num` int unsigned DEFAULT '0' COMMENT '帖子数',
  PRIMARY KEY (`id`),
  UNIQUE KEY `category_id_uindex` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='帖子分区';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `comment_content` varchar(500) NOT NULL COMMENT '评论内容',
  `comment_time` datetime NOT NULL COMMENT '评论时间',
  `res_id` int unsigned NOT NULL COMMENT '回复者id',
  `com_id` int unsigned NOT NULL COMMENT '被回复者id',
  `maincom_id` int unsigned DEFAULT NULL COMMENT '主评论id',
  `post_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `comment_id_uindex` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='评论';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'content_1','2025-06-02 17:11:35',1,2,NULL,2),(3,'******changed*****','2025-06-02 17:11:35',3,4,NULL,2),(4,'content_4','2025-06-02 17:11:35',4,5,NULL,2),(5,'2222222','2025-06-02 17:11:35',5,6,NULL,2),(6,'content_6','2025-06-02 17:11:35',6,7,NULL,2),(7,'222','2025-06-02 17:11:35',7,8,NULL,2),(8,'content_8','2025-06-02 17:11:35',8,9,NULL,2),(9,'content_9','2025-06-02 17:11:35',9,10,NULL,2),(10,'content_10','2025-06-02 17:11:35',10,11,NULL,2),(11,'写得好','2025-06-08 18:41:28',30,0,0,9),(14,'在这里记一下没完成的功能：用户权限控制-修改删除帖子','2025-06-08 19:21:04',2,0,0,1),(15,'回复指定的用户','2025-06-08 19:21:38',2,0,0,1),(16,'好吓人，刚刚出了bug','2025-06-08 19:40:35',2,0,0,1),(17,'为什么vscode里面和cursor里面写好的项目从idea打开就没被更新呢？\n','2025-06-08 19:48:49',2,0,0,1),(18,'好吧……搞了半天还不知道怎么移植过去，事已至此先复习大数据吧……感觉要完蛋了^^','2025-06-08 19:58:08',2,0,0,1),(19,'1111','2025-06-09 08:42:26',2,0,0,2),(20,'怎么又出bug……','2025-06-09 17:03:55',2,0,0,1),(21,'智齿！','2025-06-09 17:49:45',2,0,0,9),(23,'好吓人，刚刚又出bug，是git里面的冲突\n','2025-06-12 18:26:13',2,0,0,1),(25,'111','2025-06-12 18:26:13',2,0,0,13);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `comment_AFTER_INSERT_post` AFTER INSERT ON `comment` FOR EACH ROW BEGIN
	update post set comment_num = comment_num + 1
    where post.id = new.post_id;
    UPDATE post SET last_comment_time = NOW() WHERE id = NEW.post_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `comment_AFTER_UPDATE_post` AFTER UPDATE ON `comment` FOR EACH ROW BEGIN
	IF OLD.comment_content <> NEW.comment_content THEN
        UPDATE post SET last_comment_time = NOW() WHERE id = NEW.post_id;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `comment_AFTER_DELETE_post` AFTER DELETE ON `comment` FOR EACH ROW BEGIN
	 -- 检查post_id对应的帖子是否存在
    DECLARE post_exists INT;
    SELECT COUNT(*) INTO post_exists FROM post WHERE id = old.post_id;

    -- 如果帖子存在，则更新comment_num
    IF post_exists > 0 THEN
		update post set comment_num = comment_num - 1 where old.post_id=post.id;
	END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary view structure for view `popularity`
--

DROP TABLE IF EXISTS `popularity`;
/*!50001 DROP VIEW IF EXISTS `popularity`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `popularity` AS SELECT 
 1 AS `id`,
 1 AS `create_user`,
 1 AS `popu`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `post`
--

DROP TABLE IF EXISTS `post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `post` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL COMMENT '主题',
  `content` varchar(10240) DEFAULT NULL COMMENT '内容',
  `create_user` int unsigned DEFAULT NULL COMMENT '发帖人id',
  `create_time` datetime NOT NULL COMMENT '发布时间',
  `views` int unsigned NOT NULL DEFAULT '0' COMMENT '浏览量',
  `kudos` int unsigned DEFAULT '0' COMMENT '点赞数',
  `comment_num` int unsigned NOT NULL DEFAULT '0' COMMENT '评论量',
  `last_comment_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `post_id_uindex` (`id`) /*!80000 INVISIBLE */,
  KEY `post_user_fk_idx` (`create_user`),
  CONSTRAINT `post_user_id_fk` FOREIGN KEY (`create_user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='帖子';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post`
--

LOCK TABLES `post` WRITE;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` VALUES (1,'t1','其实这里是碎碎念因为大家总不会删除第一个帖子的^^',1,'2025-03-06 00:00:00',10,2,8,'2025-06-08 19:58:44'),(2,'t2','c2',2,'2025-03-05 00:00:00',14532,1441,38,'2025-06-04 11:29:04'),(3,'t3','c3',3,'2025-03-04 00:00:00',1373,316,410,NULL),(4,'t4','c4',4,'2025-03-03 00:00:00',12345,1024,321,NULL),(5,'t5','c5',5,'2025-03-02 00:00:00',531,200,22,NULL),(6,'t6','c6',1,'2025-03-01 00:00:00',612,50,0,NULL),(7,'t7','c7',2,'2025-04-11 00:00:00',37546,6425,246,NULL),(9,'《西线无战事》读后感','　　“我看见民族间被迫为敌。人民沉默、无知、愚蠢、顺从，无辜地互相杀戮。我看见世界上最聪明的头脑在制造武器和言辞，好让这一切更精妙、更持久地延续下去。”这是我初中时在学校发的资料上看到的，当时甚为震撼，抄在了积累本上。如今终于有机会来拜读这部著作。\n\n　　1.2万人点评的“神作”并非虚名。这不只是一本小说，这是一部纪实文学，一部凝固的纪录片，一叠密密麻麻的证据。政客们轻描淡写的、百姓们无从得知的，作者把它薄薄的遮羞布撕开，露出血淋淋的事实来。借着保罗的视角，从前线到家乡，再回到前线，然后是野战医院，全方面地刻画着战争带来的压倒性、彻底性的毁灭。被当做资源用以消耗的士兵，活在被构造的乌托邦里空谈大义的民众，对死亡麻木、或是无能为力或是粗暴地一刀斩敷衍了事的医生…在战争下存活的一代人，已经彻底被战争毁灭了，无论是身体上，还是灵魂上。\n\n　　20年的时间，怀胎十月来到世间，学会走路、学会说话、学会写字，阅读、理解，最后产生五彩缤纷的思想，塑造成每个独特的个体，然后被送往战场，在一公里的来回拉扯中成为灰烬。二十年的努力，一切绚烂的思想，就在炮声中轻而易举地消弭，而他们本该有各有特色的人生。成为了时代的尘土，连眼泪都没留下。而死亡每时每分每秒都在前线饱食。\n\n　　死在战场的是故事的主角，作为原型的作者活了下来，但手稿在诉说：作者曾经的真正的自我也许也跟着保罗一起死在了战场。\n\n　　再想到现在还在战争中的国家、地区，俄乌冲突、巴以冲突，在炮火中结婚却在不久后双双殒命的夫妻，说“他们不会让我活到长大”的小女孩，也许在我打下这行字的时候，遥远的远方又有谁失去了爸爸妈妈、爱人或孩子。\n\n　　战争从来不是热血浪漫，它是一场灾难，一个理由，是天启四骑士，是根植于人类中的疫病。\n\n　　',1,'2025-06-08 17:53:08',0,63,2,'2025-06-08 18:29:40'),(12,'啊哈哈','道爷我成了！',2,'2025-06-08 19:18:31',0,0,0,'2025-06-08 19:18:31'),(13,'test','test',3,'2025-06-08 19:18:31',0,0,1,'2025-06-12 20:00:39'),(14,'test','test',6,'2025-06-08 19:18:31',0,0,0,NULL),(16,'test','test',5,'2025-06-08 19:18:31',0,0,0,NULL),(17,'test','test',5,'2025-06-08 19:18:31',0,0,0,NULL);
/*!40000 ALTER TABLE `post` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `post_AFTER_DELETE_comment` AFTER DELETE ON `post` FOR EACH ROW BEGIN
	DELETE FROM comment WHERE comment.post_id = old.id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `tag`
--

DROP TABLE IF EXISTS `tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tag` (
  `id` int unsigned NOT NULL COMMENT '标签id',
  `tag_name` varchar(10) NOT NULL COMMENT '标签名',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tag_id_uindex` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='标签';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag`
--

LOCK TABLES `tag` WRITE;
/*!40000 ALTER TABLE `tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test`
--

DROP TABLE IF EXISTS `test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test` (
  `idtest` int unsigned NOT NULL AUTO_INCREMENT COMMENT '测试id',
  `username` varchar(20) NOT NULL COMMENT '用户名',
  `instruction` varchar(45) DEFAULT NULL COMMENT '简介',
  `gender` int DEFAULT NULL,
  PRIMARY KEY (`idtest`),
  UNIQUE KEY `idtest_UNIQUE` (`idtest`)
) ENGINE=InnoDB AUTO_INCREMENT=12101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='测试批量存入';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test`
--

LOCK TABLES `test` WRITE;
/*!40000 ALTER TABLE `test` DISABLE KEYS */;
INSERT INTO `test` VALUES (1,'name_1','instruction_1',1),(2,'name_2','instruction_2',0),(3,'name_3','instruction_3',0),(4,'name_4','instruction_4',0),(5,'name_5','instruction_5',0),(6,'name_6','instruction_6',1),(7,'name_7','instruction_7',1),(8,'name_8','instruction_8',1),(9,'name_9','instruction_9',1),(10,'name_10','instruction_10',0),(11,'name_11','instruction_11',0),(12,'name_12','instruction_12',0),(13,'name_13','instruction_13',1),(14,'name_14','instruction_14',1),(15,'name_15','instruction_15',0),(16,'name_16','instruction_16',0),(17,'name_17','instruction_17',1),(18,'name_18','instruction_18',1),(19,'name_19','instruction_19',0),(20,'name_20','instruction_20',1),(21,'name_21','instruction_21',0),(22,'name_22','instruction_22',0),(23,'name_23','instruction_23',1),(24,'name_24','instruction_24',1),(25,'name_25','instruction_25',1),(26,'name_26','instruction_26',0),(27,'name_27','instruction_27',1),(28,'name_28','instruction_28',0),(29,'name_29','instruction_29',1),(30,'name_30','instruction_30',1),(31,'name_31','instruction_31',1),(32,'name_32','instruction_32',0),(33,'name_33','instruction_33',1),(34,'name_34','instruction_34',1),(35,'name_35','instruction_35',0),(36,'name_36','instruction_36',0),(37,'name_37','instruction_37',0),(38,'name_38','instruction_38',0),(39,'name_39','instruction_39',1),(40,'name_40','instruction_40',1),(41,'name_41','instruction_41',0),(42,'name_42','instruction_42',1),(43,'name_43','instruction_43',1),(44,'name_44','instruction_44',1),(45,'name_45','instruction_45',1),(46,'name_46','instruction_46',1),(47,'name_47','instruction_47',1),(48,'name_48','instruction_48',1),(49,'name_49','instruction_49',1),(50,'name_50','instruction_50',0),(51,'name_51','instruction_51',1),(52,'name_52','instruction_52',1),(53,'name_53','instruction_53',1),(54,'name_54','instruction_54',0),(55,'name_55','instruction_55',1),(56,'name_56','instruction_56',1),(57,'name_57','instruction_57',1),(58,'name_58','instruction_58',1),(59,'name_59','instruction_59',1),(60,'name_60','instruction_60',1),(61,'name_61','instruction_61',0),(62,'name_62','instruction_62',0),(63,'name_63','instruction_63',0),(64,'name_64','instruction_64',1),(65,'name_65','instruction_65',0),(66,'name_66','instruction_66',1),(67,'name_67','instruction_67',1),(68,'name_68','instruction_68',1),(69,'name_69','instruction_69',1),(70,'name_70','instruction_70',0),(71,'name_71','instruction_71',1),(72,'name_72','instruction_72',0),(73,'name_73','instruction_73',0),(74,'name_74','instruction_74',1),(75,'name_75','instruction_75',1),(76,'name_76','instruction_76',1),(77,'name_77','instruction_77',0),(78,'name_78','instruction_78',0),(79,'name_79','instruction_79',1),(80,'name_80','instruction_80',1),(81,'name_81','instruction_81',1),(82,'name_82','instruction_82',0),(83,'name_83','instruction_83',1),(84,'name_84','instruction_84',0),(85,'name_85','instruction_85',0),(86,'name_86','instruction_86',1),(87,'name_87','instruction_87',0),(88,'name_88','instruction_88',0),(89,'name_89','instruction_89',1),(90,'name_90','instruction_90',0),(91,'name_91','instruction_91',0),(92,'name_92','instruction_92',0),(93,'name_93','instruction_93',1),(94,'name_94','instruction_94',1),(95,'name_95','instruction_95',1),(96,'name_96','instruction_96',1),(97,'name_97','instruction_97',0),(98,'name_98','instruction_98',0),(99,'name_99','instruction_99',1),(100,'name_100','instruction_100',0);
/*!40000 ALTER TABLE `test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test1`
--

DROP TABLE IF EXISTS `test1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test1` (
  `idtest` int unsigned NOT NULL AUTO_INCREMENT COMMENT '测试id',
  `username` varchar(20) NOT NULL COMMENT '用户名',
  `instruction` varchar(45) DEFAULT NULL COMMENT '简介',
  `gender` int DEFAULT NULL,
  `id` int DEFAULT NULL,
  PRIMARY KEY (`idtest`),
  UNIQUE KEY `idtest_UNIQUE` (`idtest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='测试批量存入';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test1`
--

LOCK TABLES `test1` WRITE;
/*!40000 ALTER TABLE `test1` DISABLE KEYS */;
/*!40000 ALTER TABLE `test1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int unsigned NOT NULL AUTO_INCREMENT COMMENT '用户id',
  `nickname` varchar(20) DEFAULT 'momo' COMMENT '昵称',
  `password` varchar(20) NOT NULL COMMENT '密码',
  `signup_date` date NOT NULL COMMENT '创建时间',
  `level` int unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `introduction` varchar(64) NOT NULL DEFAULT 'yeah remain mysterious' COMMENT '简介',
  `email` varchar(45) NOT NULL DEFAULT 'not set' COMMENT '绑定邮箱',
  `gender` char(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id_uindex` (`id`),
  CONSTRAINT `gender_limit` CHECK ((`gender` in (_utf8mb4'男',_utf8mb4'女'))),
  CONSTRAINT `level_range` CHECK (((`level` >= 0) and (`level` <= 100)))
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='用户';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'aa','yjy1','2025-03-01',0,'i\'m no.1','aa@email',NULL),(2,'yue','yjy2','2025-03-02',0,'the one after no.1','bb@email',NULL),(3,'cc','yjy3','2025-03-03',0,'three’s a crowd','cc@email',NULL),(4,'dd','yjy4','2025-03-04',0,'there is four-leaf clover','dd@email',NULL),(5,'ee','yjy5','2025-03-05',0,'yeah remain mysterious','ee@email',NULL),(6,'66','yjy6','2025-05-11',0,'yeah remain mysterious','not set',NULL),(7,'77','yjy7','2025-04-01',0,'yeah remain mysterious','not set','男'),(11,'qq','qq','2025-05-28',0,'qq','qq','女'),(17,'5','2','2025-05-28',0,'2','2',NULL),(18,'5','2','2025-05-28',0,'2','2',NULL),(19,'5','2','2025-05-28',0,'2','22281236@bjtu.edu.cn',NULL),(20,'5','11','2025-05-28',0,'2','55',NULL),(21,'5','11','2025-05-28',0,'2','55@22',NULL),(22,'5','333','2025-05-28',0,'2','55',NULL),(23,'5','333','2025-05-28',0,'2','55',NULL),(24,'5','333','2025-05-28',0,'2','55@789',NULL),(25,'5','2','2025-05-28',0,'2','2@3',NULL),(26,'5','2','2025-05-28',0,'2','2@3',NULL),(27,'5','2','2025-05-28',0,'2','2@2','男'),(28,'5','2','2025-05-28',0,'2','2@2','男'),(29,'5','22','2025-05-28',0,'22','22@22','男'),(30,'linchy','admin','2025-06-08',0,'123','linchy@123',NULL),(31,'lw','admin','2025-06-08',0,'123','lw@123',NULL),(32,'varia','book','2025-06-12',0,'new world','123@123',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `bsinfo`
--

/*!50001 DROP VIEW IF EXISTS `bsinfo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `bsinfo` AS select `user`.`id` AS `id`,`user`.`nickname` AS `nickname`,`user`.`introduction` AS `introduction` from `user` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `popularity`
--

/*!50001 DROP VIEW IF EXISTS `popularity`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `popularity` (`id`,`create_user`,`popu`) AS select `post`.`id` AS `id`,`post`.`create_user` AS `create_user`,(`post`.`views` / `post`.`kudos`) AS `views / kudos` from `post` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-12 20:01:37
