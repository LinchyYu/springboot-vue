<template>
  <div class="calculator-page">
    <h1 class="title">{{ message }}</h1>
    <div class="input-group">
      <input type="number" v-model="num1" placeholder="输入第一个数字" class="input-field" />
    </div>
    <div class="input-group">
      <input type="number" v-model="num2" placeholder="输入第二个数字" class="input-field" />
    </div>
    <button @click="add" class="btn">计算</button>
    <p v-if="result !== null" class="result-message">结果：{{ result }}</p>
  </div>
</template>
<script>
import axios from 'axios';
// import HelloWorld from "@/components/HelloWorld.vue"; // 移除不必要的导入
export default {
  // components: {HelloWorld}, // 移除不必要的组件注册
  data() {
    return {
      message: "加法计算器",
      num1: 0,
      num2: 0,
      result: null
    };
  },
  methods: {
    async add() {
      try {
        const response = await axios.post('http://localhost:8888/add/add-number', {
          num1: this.num1,
          num2: this.num2
        });
        this.result = response.data;
      } catch (error) {
        console.error("请求失败：", error);
        this.result = "计算失败"; // 添加错误提示
      }
    }
  }
}
</script>
<style scoped>
.calculator-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #f5f5f5; /* 统一为 PostDetail.vue 的背景色 */
  color: #333; /* 统一为主要文本颜色 */
  font-family: "Roboto", sans-serif;
  padding: 20px;
}

.title {
  font-size: 2.5rem; /* 统一标题大小 */
  margin-bottom: 2rem;
  text-align: center;
  color: #333; /* 统一为主要文本颜色 */
  font-weight: bold;
}

.input-group {
  margin-bottom: 1rem; /* 添加间距 */
  width: 100%;
  max-width: 300px; /* 控制输入框宽度 */
}

.input-field {
  width: 100%;
  padding: 10px;
  background: white; /* 统一为 PostDetail.vue 的卡片背景色 */
  color: #333; /* 统一为主要文本颜色 */
  border: 1px solid #eee; /* 添加边框 */
  border-radius: 4px; /* 统一为 4px */
  font-size: 1rem;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 统一为轻微阴影 */
}

.input-field:focus {
  outline: none;
  border-color: #607d8b; /* 统一为按钮默认色 */
  box-shadow: 0 0 0 2px rgba(96, 125, 139, 0.3); /* 统一为按钮默认色系的 focus 阴影 */
}

.btn {
  padding: 15px 30px; /* 统一按钮内边距 */
  background-color: #607d8b; /* 统一为 PostDetail.vue 的按钮颜色 */
  color: white;
  border: none;
  border-radius: 4px; /* 统一为 4px */
  font-size: 1.2rem; /* 统一按钮字体大小 */
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease; /* 统一过渡效果 */
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); /* 统一按钮阴影 */
}

.btn:hover {
  background-color: #78909c; /* 统一为 PostDetail.vue 的按钮 hover 颜色 */
  transform: scale(1.05);
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
}

.btn:active {
  transform: scale(0.95);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.result-message {
  margin-top: 20px;
  padding: 15px 20px;
  background: white; /* 统一背景 */
  border-radius: 8px; /* 统一圆角 */
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1); /* 统一阴影 */
  color: #333; /* 统一文本颜色 */
  text-align: center;
  max-width: 300px; /* 消息框最大宽度 */
  width: 100%;
}
</style>