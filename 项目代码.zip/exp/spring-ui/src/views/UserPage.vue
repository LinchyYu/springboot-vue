<template>
  <div class="user-list-page">
    <h1 class="main-title">User Information</h1>
    <div v-if="users.length > 0" class="user-cards-container">
      <div v-for="user in users" :key="user.id" class="user-card">
        <p><strong>ID:</strong> {{ user.id }}</p>
        <p><strong>Name:</strong> {{ user.nickname }}</p>
        <p><strong>Signup_date:</strong> {{ user.signup_date }}</p>
        <p><strong>Level:</strong> {{ user.level }}</p>
        <p><strong>Introduction:</strong>{{ user.introduction }}</p>
        <p><strong>Email:</strong>{{ user.email }}</p>
        <p><strong>Gender:</strong>{{ user.gender }}</p>
      </div>
    </div>
    <div v-else>
      <p class="info-message">Loading user information...</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      users: [], // 用于存储从后端获取的用户信息
    };
  },
  created() {
    this.getUserData(); // 组件创建时调用获取数据的方法
  },
  methods: {
    async getUserData() {
      try {
        const response = await axios.get('http://localhost:8888/users/get-allusers'); // 向后端请求数据
        // console.log(response.data);
        this.users=response.data;
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    },
  },
};
</script>

<style scoped>
.user-list-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background-color: #f5f5f5; /* 统一背景色 */
  font-family: "Roboto", sans-serif; /* 统一字体 */
  color: #333; /* 主要文本颜色 */
  padding: 20px;
}

.main-title {
  font-size: 2.5rem; /* 统一标题大小 */
  margin-bottom: 2rem;
  text-align: center;
  color: #333; /* 统一标题颜色 */
  font-weight: bold;
}

.user-cards-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); /* 类似瀑布流布局 */
  gap: 20px;
  max-width: 900px; /* 根据需要调整最大宽度 */
  width: 100%;
}

.user-card {
  background: white; /* 统一卡片背景 */
  border-radius: 8px; /* 统一圆角 */
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1); /* 统一阴影 */
  padding: 20px;
  color: #555; /* 段落文本颜色 */
  line-height: 1.6;
}

.user-card strong {
  color: #333; /* 加粗文本颜色 */
}

.info-message {
  margin-top: 20px;
  padding: 15px 20px;
  background: white; /* 统一背景 */
  border-radius: 8px; /* 统一圆角 */
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1); /* 统一阴影 */
  color: #777; /* 统一提示文本颜色 */
  text-align: center;
  max-width: 400px; /* 消息框最大宽度 */
  width: 100%;
}
</style>