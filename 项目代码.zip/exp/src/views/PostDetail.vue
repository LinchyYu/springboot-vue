<template>
  <!-- No changes to template section -->
</template>

<script>
import axios from 'axios';

export default {
  // No changes to component options
};
</script>

<style>
  /* No changes to style section */
</style>

<script>
export default {
  // No changes to methods section

  // 删除评论
  async deleteComment(commentId) {
    if (!confirm('确定要删除这条评论吗？')) {
      return;
    }
    try {
      const userId = localStorage.getItem('username');
      if (!userId) {
        this.$message.error('请先登录');
        return;
      }
      await axios.delete(`http://localhost:8888/comments/delete/${commentId}`, {
        headers: {
          'userId': userId
        }
      });
      this.$message.success('删除成功');
      // 重新加载评论列表
      this.fetchComments();
    } catch (error) {
      if (error.response) {
        switch (error.response.status) {
          case 401:
            this.$message.error('请先登录');
            break;
          case 403:
            this.$message.error('您没有权限删除此评论');
            break;
          case 404:
            this.$message.error('评论不存在');
            break;
          default:
            this.$message.error('删除失败，请稍后重试');
        }
      } else {
        this.$message.error('删除失败，请稍后重试');
      }
    }
  },
};
</script> 