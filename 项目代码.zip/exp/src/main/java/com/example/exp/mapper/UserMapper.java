//Mapper接口(DAO层)
package com.example.exp.mapper;
import com.example.exp.domain.user;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import java.util.List;
@Mapper
public interface UserMapper {
    List<user> findAllUsers();
    user findUserById(int id);
    int addUser(user newUser);
    int updateUser(user updatedUser);
    int delUser(int id);

    @Select("SELECT * FROM user WHERE username = #{username}")
    user findByUsername(String username);
}
