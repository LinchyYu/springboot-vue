package com.example.exp.controller;
import com.example.exp.domain.AddRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@RequestMapping("/add")
public class AddController {
    @PostMapping("add-number")
    public int add(@RequestBody AddRequest addRequest) {
        int num1 = addRequest.getNum1();
        int num2 = addRequest.getNum2();
        System.out.println(addRequest.toString());
        return num1 + num2;
    }
}