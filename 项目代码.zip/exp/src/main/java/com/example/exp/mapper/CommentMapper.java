package com.example.exp.mapper;

import com.example.exp.domain.Comment;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CommentMapper {

    // 添加评论
    int addComment(Comment comment);

    // 根据帖子ID查找所有评论
    List<Comment> findCommentsByPostId(int postId);

    // 根据评论ID删除评论
    int deleteCommentById(int commentId);

    // 根据评论ID查找评论
    Comment findCommentById(int id);

    // 更新评论
    int updateComment(Comment comment);
}