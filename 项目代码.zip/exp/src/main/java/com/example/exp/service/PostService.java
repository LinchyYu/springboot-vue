package com.example.exp.service;

import com.example.exp.domain.post;
import java.util.List;

public interface PostService {
    List<post> getAllPosts();
    post findPostById(int id);
    post addPost(post newPost);
    post updatePost(post updatedPost);
    post delPost(int id);
    post addKudos(int id);
}
