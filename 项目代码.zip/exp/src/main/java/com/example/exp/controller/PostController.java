package com.example.exp.controller;
import com.example.exp.domain.post;
import com.example.exp.service.PostService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import java.util.List;

@RestController
@RequestMapping("/posts")
public class PostController {
    private final PostService postService;
    
    public PostController(PostService postService) {
        this.postService = postService;
    }
    
    @GetMapping("/get-allposts")
    public List<post> getAllPosts() {
        return postService.getAllPosts();
    }
    
    @GetMapping("/get/{id}")
    public post getPostById(@PathVariable int id) {
        return postService.findPostById(id);
    }
    
    @PostMapping("/add-post")
    public post addPost(@RequestBody post newPost) {
        return postService.addPost(newPost);
    }
    
    @DeleteMapping("/delete/{id}")
    public post delPost(@PathVariable int id) {
        return postService.delPost(id);
    }
    
    @PutMapping("/update/{id}")
    public post updatePost(@PathVariable int id, @RequestBody post updatePost) {
        updatePost.setId(id); // Ensure the ID from path variable is set to the post object
        return postService.updatePost(updatePost);
    }
    
    @PutMapping("/kudos/{id}")
    public post addKudos(@PathVariable int id) {
        return postService.addKudos(id);
    }
}