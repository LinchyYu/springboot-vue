import { createRouter, createWebHistory } from 'vue-router';
import index from "@/views/index.vue";
import userindex from '@/views/userindex.vue';
import add from '@/views/AddPage.vue';
import userPage from "@/views/UserPage.vue";
import JumpPage from "@/views/JumpPage.vue";
import AddUser from '@/views/AddUserPage.vue';
import DelUser from "@/views/DelUserPage.vue";
import UpdateUserPage from "@/views/UpdateUserPage.vue";
import SearPage from "@/views/SearPage.vue";
import SearOneUser from "@/views/SearOneUserPage.vue";
import SearUser from "@/views/SearUserPage.vue";
import EditPost from '@/views/EditPostPage.vue';
import DeletePost from '@/views/DeletePostPage.vue';

const routes = [
  {
    path: '/',
    redirect: '/index',
  },
  {
    path: '/userindex',
    name: 'userindex',
    component: userindex,
  },
  {
    path: '/adduser',
    name: 'AddUser',
    component: AddUser,
  },
  {
    path: '/deluser',
    name: 'DelUser',
    component: DelUser,
  },
  {
    path: '/updateuser',
    name: 'UpdateUser',
    component: UpdateUserPage,
  },
  {
    path: '/searpage',
    name: 'SearPage',
    component: SearPage,
  },
  {
    path: '/searoneuser',
    name: 'SearOneUser',
    component: SearOneUser,
  },
  {
    path: '/searuser',
    name: 'SearUser',
    component: SearUser,
  },
  {
    path: '/add',
    name: 'AddPage',
    component: add,
  },
  {
    path: '/user',
    name: 'userPage',
    component: userPage,
  },
  {
    path:'/jump',
    name: 'JumpPage',
    component: JumpPage,
  },
  {
    path: '/index',
    name: 'index',
    component: index,
  },
  {
    path: '/post/:id',
    name: 'PostDetail',
    component: () => import('@/views/PostDetail.vue'),
  },
  {
    path: '/addpost',
    name: 'AddPost',
    component: () => import('@/views/AddPostPage.vue'),
  },
  {
    path: '/editpost/:id',
    name: 'EditPost',
    component: EditPost,
  },
  {
    path: '/deletepost/:id',
    name: 'DeletePost',
    component: DeletePost,
  },
];
const router = createRouter({
  history: createWebHistory(),
  routes,
});
export default router;