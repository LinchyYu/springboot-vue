<template>
  <div class="jump-page">
    <h1 class="title">Jump Page</h1>
    <!-- 跳转按钮 -->
    <button @click="goToAddPage" class="btn">前往添加页面</button>
  </div>
</template>

<script>
export default {
  methods: {
    goToAddPage() {
      // 方式1：通过路由名称跳转（更推荐，避免硬编码路径）
      this.$router.push({ name: 'AddPage' });
      // 方式2：直接使用路径跳转
      // this.$router.push('/add');
    }
  }
}
</script>
<style scoped>
.jump-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #f5f5f5; /* 统一为 PostDetail.vue 的背景色 */
  color: #333; /* 统一为主要文本颜色 */
  font-family: "Roboto", sans-serif;
  padding: 20px;
}

.title {
  font-size: 2.5rem; /* 统一标题大小 */
  margin-bottom: 2rem;
  text-align: center;
  color: #333; /* 统一为主要文本颜色 */
  font-weight: bold;
}

.btn {
  padding: 15px 30px; /* 统一按钮内边距 */
  background-color: #607d8b; /* 统一为 PostDetail.vue 的按钮颜色 */
  color: white;
  border: none;
  border-radius: 4px; /* 统一为 4px */
  font-size: 1.2rem; /* 统一按钮字体大小 */
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease; /* 统一过渡效果 */
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2); /* 统一按钮阴影 */
}
.btn:hover {
  background-color: #78909c; /* 统一为 PostDetail.vue 的按钮 hover 颜色 */
  transform: scale(1.05);
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
}
.btn:active {
  transform: scale(0.95);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}
</style>