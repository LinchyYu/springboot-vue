<template>
  <div class="table-container">
    <h1 class="main-title">User Information</h1>
<!--    <div v-if="users.length > 0">-->
<!--      <div v-for="user in users" :key="user.id">-->
<!--        <p><strong>ID:</strong> {{ user.id }}</p>-->
<!--        <p><strong>Name:</strong> {{ user.nickname }}</p>-->
<!--        <p><strong>Signup_date:</strong> {{ user.signup_date }}</p>-->
<!--        <p><strong>Level:</strong> {{ user.level }}</p>-->
<!--        <p><strong>Email:</strong>{{ user.email }}</p>-->
<!--        <p><strong>Introduction:</strong>{{ user.introduction }}</p>-->
<!--      </div>-->
<!--    </div>-->
<!--    <div v-else>-->
<!--      <p>Loading user information...</p>-->
<!--    </div>-->

<!--    表格形式-->
    <div v-if="users.length > 0" class="table-wrapper">
      <table>
        <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Signup_date</th>
          <th>Level</th>
          <th>Email</th>
          <th>Introduction</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="user in users" :key="user.id">
          <td>{{ user.id }}</td>
          <td>{{ user.nickname }}</td>
          <td>{{ user.signup_date }}</td>
          <td>{{ user.level }}</td>
          <td>{{ user.email }}</td>
          <td>{{ user.introduction }}</td>
        </tr>
        </tbody>
      </table>
    </div>
    <div v-else>
      <p class="info-message">Loading user information...</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      users: [], // 用于存储从后端获取的用户信息
    };
  },
  created() {
    this.getUserData(); // 组件创建时调用获取数据的方法
  },
  methods: {
    async getUserData() {
      try {
        const response = await axios.get('http://localhost:8888/users/get-allusers'); // 向后端请求数据
        // console.log(response.data);
        this.users=response.data;
      } catch (error) {
        console.error('Error fetching user data:', error);
      }
    },
  },
};
</script>

<style scoped>
.table-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;
  min-height: 100vh;
  background-color: #f5f5f5; /* 统一背景色 */
  font-family: 'Roboto', sans-serif; /* 统一字体 */
  color: #333; /* 统一主要文本颜色 */
}

.main-title {
  color: #333; /* 统一标题颜色 */
  margin-bottom: 20px;
  font-size: 2.5rem; /* 统一标题大小 */
  font-weight: bold;
  text-align: center;
}

.table-wrapper {
  width: 100%;
  max-width: 800px; /* 控制表格最大宽度 */
  background-color: white; /* 统一表格背景色 */
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1); /* 统一阴影 */
  border-radius: 8px; /* 统一圆角 */
  overflow: hidden; /* 确保内容在圆角内 */
}

table {
  width: 100%;
  border-collapse: collapse;
  margin: 0; /* 移除自动外边距，由父容器控制 */
}

th,
td {
  padding: 12px 15px; /* 调整内边距 */
  text-align: left;
  border-bottom: 1px solid #eee; /* 统一分割线颜色 */
  color: #333; /* 统一表格文本颜色 */
}

thead {
  background-color: #607d8b; /* 统一表头背景颜色 */
  color: white; /* 统一表头文字颜色 */
}

tr:nth-child(even) {
  background-color: white; /* 统一偶数行背景色，保持简洁 */
}

tr:hover {
  background-color: rgba(0, 0, 0, 0.05); /* 统一鼠标悬停时的背景颜色 */
}

.info-message {
  margin-top: 20px;
  padding: 15px 20px;
  background: white; /* 统一背景色 */
  border-radius: 8px; /* 统一圆角 */
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1); /* 统一阴影 */
  color: #777; /* 统一文本颜色 */
  text-align: center;
  max-width: 400px; /* 消息框最大宽度 */
  width: 100%;
}
</style>