<template>
  <div class="post-detail-container">
    <h2 class="main-page-title">帖子详情</h2>
    
    <div class="main-content-wrapper">
      <div class="top-bar-aligned">
        <button @click="goBack" class="back-btn">返回首页</button>
        <div class="action-buttons">
          <button v-if="isLoggedIn && hasPermission" @click="editPost" class="edit-btn">修改帖子</button>
          <button v-if="isLoggedIn && hasPermission" @click="deletePost" class="delete-btn">删除帖子</button>
        </div>
      </div>
      
      <div v-if="post" class="post-content-detail">
        <div class="post-info-header"> 
          <span class="author-name">作者：{{ post.nickname }}</span>
          <span class="publish-time">发布时间：{{ post.create_time }}</span>
        </div>
        <h3 class="post-detail-title">{{ post.title }}</h3>
        <p class="post-detail-text">{{ post.content }}</p>
        <div class="post-meta-bottom">
          <button class="kudos-btn" @click="addKudos">点赞</button>
          <p class="kudos-display">点赞数：<span class="kudos-count">{{ post.likes }}</span></p>
          <!-- <p>评论数：{{ comments.length }}</p> -->
        </div>
      </div>
      <div v-else class="loading-text">
        加载中...或帖子不存在
      </div>

      <!-- 评论区 -->
      <div class="comments-section">
        <h3>评论 ({{ comments.length }})</h3>
        <div v-if="isLoggedIn" class="add-comment-form">
          <textarea v-model="newCommentContent" placeholder="发表你的评论..." class="comment-textarea"></textarea>
          <button @click="submitComment" :disabled="!newCommentContent.trim()" class="submit-comment-btn">提交评论</button>
        </div>
        <p v-else class="login-to-comment-msg">请登录后发表评论。</p>

        <div class="comments-list">
          <div v-if="comments.length === 0" class="no-comments-msg">暂无评论，快来发表第一条评论吧！</div>
          <div v-for="comment in comments" :key="comment.id" class="comment-item">
            <div class="comment-header">
              <span class="comment-author">{{ comment.nickname }}</span>
              <span class="comment-time">{{ formatTime(comment.comment_time) }}</span>
            </div>
            <p class="comment-content">{{ comment.comment_content }}</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'PostDetail',
  data() {
    return {
      post: null,
      comments: [],
      newCommentContent: '',
      isLoggedIn: false,
      loggedInUserId: null,
      loggedInNickname: null,
      hasPermission: false,
    }
  },
  mounted() {
    this.checkLoginStatus();
    this.fetchPost();
    this.fetchComments();
  },
  methods: {
    checkLoginStatus() {
      const userId = localStorage.getItem('username');
      const nickname = localStorage.getItem('nickname');
      this.isLoggedIn = !!userId && !!nickname;
      this.loggedInUserId = userId ? parseInt(userId, 10) : null;
      this.loggedInNickname = nickname;
    },
    formatTime(time) {
      if (!time) return ''
      const date = new Date(time)
      const now = new Date()
      const diff = now - date
      
      // 小于1分钟
      if (diff < 60000) {
        return '刚刚'
      }
      // 小于1小时
      if (diff < 3600000) {
        return Math.floor(diff / 60000) + '分钟前'
      }
      // 小于24小时
      if (diff < 86400000) {
        return Math.floor(diff / 3600000) + '小时前'
      }
      // 小于30天
      if (diff < 2592000000) {
        return Math.floor(diff / 86400000) + '天前'
      }
      // 大于30天
      return date.toLocaleDateString()
    },
    async fetchPost() {
      try {
        const id = this.$route.params.id;
        const response = await axios.get(`http://localhost:8888/posts/get/${id}`);
        if (response.data) {
          this.post = response.data;
          // 在获取到帖子数据后检查权限
          this.checkPermission();
        } else {
          console.warn(`获取帖子ID ${id} 详情成功，但数据为空。`);
          this.post = null;
        }
      } catch (error) {
        console.error('获取帖子详情失败:', error);
        alert('获取帖子详情失败，请稍后重试');
      }
    },
    async fetchComments() {
      try {
        const postId = this.$route.params.id;
        const response = await axios.get(`http://localhost:8888/comments/post/${postId}`);
        if (response.data) {
          this.comments = response.data;
        } else {
          console.warn(`获取帖子ID ${postId} 的评论成功，但数据为空。`);
          this.comments = [];
        }
      } catch (error) {
        console.error('获取评论失败:', error);
        // alert('获取评论失败，请稍后重试'); // 可以选择是否弹出错误
      }
    },
    async submitComment() {
      if (!this.newCommentContent.trim()) {
        alert('评论内容不能为空！');
        return;
      }
      if (!this.isLoggedIn) {
        alert('请先登录才能发表评论。');
        return;
      }

      try {
        const postId = parseInt(this.$route.params.id);
        const commentData = {
          comment_content: this.newCommentContent,
          res_id: this.loggedInUserId,
          post_id: postId,
          com_id: 0, // 暂时为空，先不管
          maincom_id: 0 // 暂时为空，先不管
        };

        const response = await axios.post('http://localhost:8888/comments/add-comment', commentData);
        if (response.status === 201) { // HTTP 201 Created
          alert('评论发表成功！');
          this.newCommentContent = ''; // 清空输入框
          this.fetchComments(); // 重新加载评论列表
        } else if (response.status === 401) {
          alert('评论失败：您未登录。');
        } else {
          alert('评论失败，请稍后重试。');
        }
      } catch (error) {
        console.error('提交评论失败:', error);
        if (error.response && error.response.status === 401) {
          alert('评论失败：您未登录或会话已过期，请重新登录。');
        } else {
          alert('提交评论失败，请检查网络或后端。');
        }
      }
    },
    async addKudos() {
      if (!this.post || !this.post.id) return;
      try {
        // 发送 PUT 请求到后端点赞接口
        const response = await axios.put(`http://localhost:8888/posts/kudos/${this.post.id}`);
        if (response.status === 200) {
          // 点赞成功，更新前端点赞数
          this.post.likes = response.data.likes; // 假设后端返回了更新后的post对象
          alert('点赞成功！');
        } else {
          console.log(this.post);
          alert('点赞失败，请稍后重试。');
        }
      } catch (error) {
        console.error('点赞失败:', error);
        alert('点赞失败，请检查网络或后端。');
      }
    },
    goBack() {
      this.$router.push({ name: 'index' }); // 返回首页
    },
    editPost() {
      // 跳转到修改帖子页面
      this.$router.push({ name: 'EditPost', params: { id: this.post.id } });
    },
    deletePost() {
      // 跳转到删除帖子页面
      this.$router.push({ name: 'DeletePost', params: { id: this.post.id } });
    },
    // 新增权限检查方法
    checkPermission() {
      if (this.loggedInUserId && this.post?.authorId) {
        this.hasPermission = Number(this.loggedInUserId) === Number(this.post.authorId);
        console.log('权限检查:', {
          loggedInUserId: this.loggedInUserId,
          postAuthorId: this.post.authorId,
          hasPermission: this.hasPermission
        });
      } else {
        this.hasPermission = false;
      }
    }
  }
}
</script>

<style scoped>
.post-detail-container {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center; /* 使整个页面内容（包括标题和 wrapper）垂直居中对齐 */
}

.main-page-title {
  text-align: center;
  color: #333;
  margin-bottom: 30px;
  font-size: 2em;
}

.main-content-wrapper {
  width: 100%;
  max-width: 800px; /* 设置与帖子内容区域相同的最大宽度 */
  /* margin: 0 auto; 自动居中 */
}

.top-bar-aligned {
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between; /* 按钮靠左和靠右 */
  align-items: center;
}

.back-btn {
  padding: 8px 16px;
  background-color: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
}

.back-btn:hover {
  background-color: #78909c;
}

.action-buttons {
  display: flex;
  gap: 10px;
}

.edit-btn, .delete-btn {
  padding: 8px 16px;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
}

.edit-btn {
  background-color: #4CAF50;
}

.edit-btn:hover {
  background-color: #45a049;
}

.delete-btn {
  background-color: #f44336;
}

.delete-btn:hover {
  background-color: #d32f2f;
}

.post-content-detail {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 30px;
  width: 100%; /* 确保在max-width内能撑满 */
}

.post-info-header {
  display: flex;
  align-items: center;
  margin-bottom: 10px;
  font-size: 0.9em;
  color: #777;
  text-align: left;
}

.author-name {
  font-weight: bold;
  margin-right:30px;
  color: #333;
}

.publish-time {
  color: #999;
}

.post-detail-title {
  font-size: 2em;
  color: #333;
  margin-bottom: 15px;
  text-align: left;
}

.post-detail-text {
  font-size: 1.1em;
  color: #555;
  line-height: 1.8;
  white-space: pre-wrap;
  text-align: left;
  margin-bottom: 20px;
}

.post-meta-bottom {
  font-size: 0.9em;
  color: #777;
  border-top: 1px solid #eee;
  padding-top: 15px;
  text-align: left;
  display: flex; /* Make it a flex container */
  align-items: center; /* Vertically align items */
  gap: 20px; /* Add space between items */
}

.post-meta-bottom p {
  margin-bottom: 5px;
}

.loading-text {
  text-align: center;
  color: #999;
  font-size: 1.1em;
  padding: 50px;
}

/* 评论区样式 */
.comments-section {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 30px;
  width: 100%;
  margin-top: 20px; /* 与帖子内容详情区的间距 */
}

.comments-section h3 {
  font-size: 1.5em;
  color: #333;
  margin-bottom: 20px;
  text-align: left;
}

.add-comment-form {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 20px;
}

.comment-textarea {
  width: 100%;
  min-height: 80px;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 1rem;
  resize: vertical;
}

.comment-textarea:focus {
  outline: none;
  border-color: #607d8b;
  box-shadow: 0 0 0 3px rgba(96, 125, 139, 0.3);
}

.submit-comment-btn {
  padding: 10px 20px;
  background-color: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1rem;
  transition: background-color 0.3s;
  align-self: flex-end; /* 按钮靠右对齐 */
}

.submit-comment-btn:hover {
  background-color: #78909c;
}

.submit-comment-btn:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

.login-to-comment-msg {
  color: #888;
  text-align: center;
  margin-bottom: 20px;
}

.comments-list {
  border-top: 1px solid #eee;
  padding-top: 20px;
}

.no-comments-msg {
  color: #888;
  text-align: center;
  padding: 20px 0;
}

.comment-item {
  background: #f9f9f9;
  border-radius: 6px;
  padding: 15px;
  margin-bottom: 15px;
  box-shadow: 0 1px 6px rgba(0, 0, 0, 0.05);
}

.comment-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.comment-author {
  font-weight: bold;
  color: #333;
}

.comment-time {
  color: #999;
  font-size: 0.9em;
}

.comment-content {
  color: #555;
  line-height: 1.6;
  white-space: pre-wrap;
  text-align: left;
}

/* 点赞功能样式 */
.kudos-btn {
  padding: 8px 16px; /* Similar padding to other buttons */
  background-color: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px; /* Similar font size */
  transition: background-color 0.3s; /* Smooth transition */
}
.kudos-btn:hover {
  background-color: #78909c;
}

.kudos-display {
  /* cursor: pointer; */ /* Removed as button handles click */
  display: flex;
  align-items: center;
  color: #777;
  /* transition: color 0.3s; */ /* Removed as button handles hover */
}

/* .kudos-display:hover { */
/*   color: #607d8b; */ /* Removed as button handles hover */
/* } */

.kudos-count {
  font-weight: bold;
  margin-left: 5px;
  color: #333;
}
</style> 