<!--<template>-->
<!--  <div class="index-page">-->
<!--    <h1>请选择功能</h1><br>-->
<!--    &lt;!&ndash; 跳转按钮 &ndash;&gt;-->
<!--    <div class="ui-button">-->
<!--      <button @click="goToSearUserPage" class="btn">前往查询全部用户</button>-->
<!--    </div>-->
<!--    <br>-->
<!--    <div class="ui-button">-->
<!--      <button @click="goToSearOneUserPage" class="btn">前往查询单个用户</button>-->
<!--    </div>-->
<!--    <br>-->
<!--  </div>-->
<!--</template>-->

<!--<script>-->
<!--export default {-->
<!--  methods: {-->
<!--    goToSearUserPage() {-->
<!--      // 方式1：通过路由名称跳转（更推荐，避免硬编码路径）-->
<!--      this.$router.push({ name: 'SearUser' });-->
<!--      // 方式2：直接使用路径跳转-->
<!--      // this.$router.push('/add');-->
<!--    },-->
<!--    goToSearOneUserPage() {-->
<!--      this.$router.push({ name: 'SearOneUser' });-->
<!--    },-->
<!--  }-->
<!--}-->
<!--</script>-->
<!--<style scoped>-->
<!--.btn {-->
<!--  padding: 10px 20px;-->
<!--  background-color: #4CAF50;-->
<!--  color: white;-->
<!--  border: none;-->
<!--  border-radius: 4px;-->
<!--  cursor: pointer;-->
<!--}-->
<!--.btn:hover {-->
<!--  background-color: #45a049;-->
<!--}-->
<!--</style>-->

<template>
  <div class="index-page">
    <h1 class="title">请选择功能</h1>
    <!-- 跳转按钮 -->
    <div class="ui-button">
      <button @click="goToSearUserPage" class="btn">前往查询全部用户</button>
    </div>
    <div class="ui-button">
      <button @click="goToSearOneUserPage" class="btn">前往查询单个用户</button>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    goToSearUserPage() {
      this.$router.push({ name: 'SearUser' });
    },
    goToSearOneUserPage() {
      this.$router.push({ name: 'SearOneUser' });
    },
  }
}
</script>

<style scoped>
.index-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  background: #f5f5f5;
  color: #333;
  font-family: "Roboto", sans-serif;
  padding: 20px;
}

.title {
  font-size: 2.5rem;
  margin-bottom: 2rem;
  text-align: center;
  color: #333;
  text-shadow: none;
  font-weight: bold;
}

.ui-button {
  margin: 10px 0;
}

.btn {
  padding: 15px 30px;
  background: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1.2rem;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  text-shadow: none;
}

.btn:hover {
  background: #78909c;
  transform: scale(1.05);
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
}

.btn:active {
  transform: scale(0.95);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}
</style>