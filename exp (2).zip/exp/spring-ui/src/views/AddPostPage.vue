<template>
  <div class="add-post-page">
    <h1 class="main-page-title">发布新帖子</h1>
    
    <div class="main-content-wrapper">
      <div class="top-bar-aligned">
        <button @click="goBack" class="back-btn">返回首页</button>
      </div>

      <form @submit.prevent="addPost" class="post-form">
        <div class="input-group">
          <label for="title">帖子标题：</label>
          <input type="text" id="title" v-model="post.title" placeholder="请输入帖子标题" required class="input-field" />
        </div>
        <div class="input-group">
          <label for="content">帖子内容：</label>
          <textarea id="content" v-model="post.content" placeholder="请输入帖子内容" required class="textarea-field"></textarea>
        </div>
        
        <button type="submit" class="btn">发布帖子</button>
      </form>

      <div v-if="addSuccess" class="success-message">
        <p>帖子发布成功！</p>
        <p>标题: {{ newPost.title }}</p>
        <p>内容: {{ newPost.content }}</p>
        <!-- 可以显示更多新帖子的信息 -->
      </div>
      <div v-if="addError" class="error-message">
        <p>发布帖子失败，请重试。</p>
        <p v-if="addErrorMessage">错误信息: {{ addErrorMessage }}</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'AddPostPage',
  data() {
    return {
      post: {
        title: '',
        content: '',
        authorId: null,
      },
      addSuccess: false,
      addError: false,
      addErrorMessage: '',
      newPost: null,
    };
  },
  methods: {
    async addPost() {
      this.addSuccess = false;
      this.addError = false;
      this.addErrorMessage = '';
      this.newPost = null;

      // 获取存储在 localStorage 中的 token 和 username（用户ID）
      const userToken = localStorage.getItem('userToken');
      const userIdString = localStorage.getItem('username'); // 从 localStorage 获取的是字符串

      if (!userToken || !userIdString) {
        this.addError = true;
        this.addErrorMessage = '请先登录才能发布帖子。';
        alert('请先登录才能发布帖子。');
        return;
      }

      // 将用户ID转换为数字并添加到 post 对象中
      const authorId = parseInt(userIdString, 10);
      if (isNaN(authorId)) {
        this.addError = true;
        this.addErrorMessage = '无效的用户ID。';
        alert('无效的用户ID，请重新登录。');
        return;
      }
      this.post.authorId = authorId; // 设置 authorId

      try {
        const response = await axios.post(
          'http://localhost:8888/posts/add-post',
          this.post,
          {
            headers: {
              'Authorization': `Bearer ${userToken}` // 将 token 添加到请求头
            }
          }
        );

        if (response.data) {
          this.newPost = response.data;
          this.addSuccess = true;
          this.post.title = '';
          this.post.content = '';
          this.post.authorId = null; // 清空 authorId
        } else {
          this.addError = true;
          this.addErrorMessage = '发布帖子失败：后端返回空数据。';
          console.error('发布帖子失败：后端返回空数据');
        }
      } catch (error) {
        this.addError = true;
        this.addErrorMessage = error.response?.data?.message || '发布帖子失败，请检查网络或后端。' + (error.response?.data?.msg || '');
        console.error('发布帖子失败:', error);
        alert('发布帖子失败，请检查网络或后端。');
      }
    },
    goBack() {
      this.$router.push({ name: 'index' });
    }
  }
}
</script>

<style scoped>
.add-post-page {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.main-page-title {
  text-align: center;
  color: #333;
  margin-bottom: 30px;
  font-size: 2em;
}

.main-content-wrapper {
  width: 100%;
  max-width: 800px; /* 与 PostDetail.vue 的内容区域宽度一致 */
}

.top-bar-aligned {
  margin-bottom: 20px;
  display: flex;
  justify-content: flex-start;
}

.back-btn {
  padding: 8px 16px;
  background-color: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
}

.back-btn:hover {
  background-color: #78909c;
}

.post-form {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 30px;
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 20px; /* 表单项之间的间距 */
}

.input-group {
  display: flex;
  flex-direction: column;
}

.input-group label {
  margin-bottom: 8px;
  font-weight: bold;
  color: #333;
}

.input-field,
.textarea-field {
  padding: 12px;
  border: 1px solid #eee;
  border-radius: 4px;
  font-size: 1rem;
  color: #333;
  background-color: #fff;
  box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.05);
}

.textarea-field {
  min-height: 120px;
  resize: vertical;
}

.input-field:focus,
.textarea-field:focus {
  outline: none;
  border-color: #607d8b;
  box-shadow: 0 0 0 3px rgba(96, 125, 139, 0.3);
}

.btn {
  padding: 15px 30px;
  background-color: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  font-size: 1.2rem;
  cursor: pointer;
  transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.2);
  align-self: flex-start; /* 按钮左对齐 */
}

.btn:hover {
  background-color: #78909c;
  transform: scale(1.02);
  box-shadow: 0 6px 10px rgba(0, 0, 0, 0.3);
}

.btn:active {
  transform: scale(0.98);
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.success-message,
.error-message {
  margin-top: 20px;
  padding: 15px 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  color: #333;
  text-align: center;
  width: 100%;
}

.success-message {
  border: 1px solid #4CAF50; /* 绿色边框 */
  color: #4CAF50;
}

.error-message {
  border: 1px solid #f44336; /* 红色边框 */
  color: #f44336;
}
</style> 