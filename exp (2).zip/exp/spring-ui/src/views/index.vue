<template>
  <div class="forum-container">
    <div class="header">
      <div class="main-title-section">
        <img src="/logo.png" alt="Logo" class="app-logo">
        <h1 class="app-title">论坛系统</h1>
      </div>
      <div class="header-buttons">
        <button @click="goToAddPost" class="add-post-btn">发布帖子</button>
        <button @click="goToUserIndex" class="user-btn">用户选项</button>
      </div>
    </div>
    <div v-loading="loading" class="waterfall-container">
      <div
        v-for="(post, index) in posts"
        :key="index"
        class="post-card"
        @click="goToPostDetail(post.id)"
        style="cursor:pointer;"
      >
        <div class="post-header">
          <span class="username">{{ post.nickname || post.username }}</span>
          <span class="post-time">{{ formatTime(post.lastReplyTime || post.createTime) }}</span>
        </div>
        <div class="post-content">
          <h3 class="post-title">{{ post.title }}</h3>
          <p class="post-text">{{ truncateContent(post.content) }}</p>
        </div>
        <div class="post-footer">
          <div class="interaction">
            <span class="label">点赞数：</span>
            <span>{{ post.likes || 0 }}</span>
          </div>
          <div class="interaction">
            <span class="label">评论数：</span>
            <span>{{ post.comments || 0 }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'ForumHome',
  data() {
    return {
      posts: [],
      loading: false
    }
  },
  mounted() {
    this.fetchPosts()
    this.initWaterfall()
  },
  methods: {
    formatTime(time) {
      if (!time) return ''
      const date = new Date(time)
      const now = new Date()
      const diff = now - date
      
      // 小于1分钟
      if (diff < 60000) {
        return '刚刚'
      }
      // 小于1小时
      if (diff < 3600000) {
        return Math.floor(diff / 60000) + '分钟前'
      }
      // 小于24小时
      if (diff < 86400000) {
        return Math.floor(diff / 3600000) + '小时前'
      }
      // 小于30天
      if (diff < 2592000000) {
        return Math.floor(diff / 86400000) + '天前'
      }
      // 大于30天
      return date.toLocaleDateString()
    },
    truncateContent(text, maxLength = 30) {
      if (!text) return '';
      if (text.length <= maxLength) {
        return text;
      }
      return text.slice(0, maxLength) + '...';
    },
    async fetchPosts() {
      this.loading = true
      try {
        const response = await axios.get('http://localhost:8888/posts/get-allposts')
        if (response.data) {
          // 按最新回复时间排序
          this.posts = response.data.sort((a, b) => {
            return new Date(b.lastReplyTime || b.createTime) - new Date(a.lastReplyTime || a.createTime)
          })
        } else {
          console.warn('获取帖子成功，但数据为空。')
          this.posts = []
        }
      } catch (error) {
        console.error('获取帖子失败:', error)
        alert('获取帖子失败，请稍后重试')
      } finally {
        this.loading = false
      }
    },
    initWaterfall() {
      const container = document.querySelector('.waterfall-container')
      if (container) {
        container.style.display = 'grid'
        container.style.gridTemplateColumns = 'repeat(auto-fill, minmax(300px, 1fr))'
        container.style.gap = '20px'
      }
    },
    goToUserIndex() {
      this.$router.push({ name: 'userindex' })
    },
    goToPostDetail(id) {
      this.$router.push({ name: 'PostDetail', params: { id: id } })
    },
    goToAddPost() {
      this.$router.push({ name: 'AddPost' })
    }
  }
}
</script>

<style scoped>
.forum-container {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 25px;
  margin-bottom: 25px;
  background-color: #ffffff;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
  border-radius: 8px;
  position: sticky;
  top: 0;
  z-index: 100;
}

.main-title-section {
  display: flex;
  align-items: center;
  gap: 15px;
}

.app-logo {
  height: 60px;
  width: auto;
  filter: drop-shadow(2px 2px 4px rgba(0, 0, 0, 0.1));
}

.app-title {
  font-size: 3em;
  color: #212121;
  margin: 0;
  font-weight: bold;
  letter-spacing: -0.5px;
}

.header-buttons {
  display: flex;
  gap: 10px;
}

.user-btn,
.add-post-btn {
  padding: 8px 16px;
  background-color: #607d8b;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  font-weight: bold;
  transition: background-color 0.3s;
}

.user-btn:hover,
.add-post-btn:hover {
  background-color: #78909c;
}

/* 保留原有的其他样式 */
.waterfall-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  padding: 20px;
}

.post-card {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: transform 0.3s;
  break-inside: avoid;
}

.post-card:hover {
  transform: translateY(-5px);
}

.post-header {
  padding: 15px;
  display: flex;
  align-items: center;
  border-bottom: 1px solid #eee;
}

.username {
  font-weight: bold;
  margin-right: 10px;
  color: #333;
}

.post-time {
  color: #999;
  font-size: 0.9em;
}

.post-content {
  padding: 15px;
}

.post-title {
  margin: 0 0 10px 0;
  font-size: 1.2em;
  color: #333;
  text-align: left;
}

.post-text {
  color: #555;
  margin-bottom: 10px;
  line-height: 1.6;
  text-align: left;
}

.post-footer {
  padding: 15px;
  display: flex;
  justify-content: space-around;
  border-top: 1px solid #eee;
}

.interaction {
  display: flex;
  align-items: center;
  color: #777;
  cursor: pointer;
  transition: color 0.3s;
}

.interaction i {
  margin-right: 5px;
}

.interaction:hover {
  color: #78909c;
}

.label {
  font-weight: bold;
  margin-right: 4px;
  color: #333;
}
</style>
