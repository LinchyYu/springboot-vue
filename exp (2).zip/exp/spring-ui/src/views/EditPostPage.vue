<template>
  <div class="edit-post-container">
    <h2 class="main-page-title">修改帖子</h2>
    
    <div class="main-content-wrapper">
      <div class="top-bar-aligned">
        <button @click="goBack" class="back-btn">返回详情页</button>
      </div>
      
      <form @submit.prevent="submitEdit" class="edit-form">
        <div class="input-group">
          <label for="title">标题:</label>
          <input type="text" id="title" v-model="post.title" placeholder="请输入标题" required class="input-field">
        </div>
        <div class="input-group">
          <label for="content">内容:</label>
          <textarea id="content" v-model="post.content" placeholder="请输入内容" required class="input-field textarea-field"></textarea>
        </div>
        <button type="submit" class="btn submit-btn">提交修改</button>
      </form>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'EditPostPage',
  data() {
    return {
      post: {
        id: null,
        title: '',
        content: ''
      }
    }
  },
  mounted() {
    this.fetchPost()
  },
  methods: {
    async fetchPost() {
      try {
        const id = this.$route.params.id
        const response = await axios.get(`http://localhost:8888/posts/get/${id}`)
        if (response.data) {
          this.post = response.data
        } else {
          console.warn(`获取帖子ID ${id} 详情成功，但数据为空。`)
          alert('获取帖子详情失败，请稍后重试')
          this.$router.push({ name: 'PostDetail', params: { id: id } })
        }
      } catch (error) {
        console.error('获取帖子详情失败:', error)
        alert('获取帖子详情失败，请稍后重试')
        this.$router.push({ name: 'PostDetail', params: { id: this.$route.params.id } })
      }
    },
    async submitEdit() {
      try {
        const id = this.$route.params.id
        await axios.put(`http://localhost:8888/posts/update/${id}`, this.post)
        alert('帖子修改成功！')
        this.$router.push({ name: 'PostDetail', params: { id: id } })
      } catch (error) {
        console.error('修改帖子失败:', error)
        alert('修改帖子失败，请稍后重试')
      }
    },
    goBack() {
      this.$router.push({ name: 'PostDetail', params: { id: this.$route.params.id } })
    }
  }
}
</script>

<style scoped>
.edit-post-container {
  padding: 20px;
  background-color: #f5f5f5;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.main-page-title {
  text-align: center;
  color: #333;
  margin-bottom: 30px;
  font-size: 2em;
}

.main-content-wrapper {
  width: 100%;
  max-width: 800px;
}

.top-bar-aligned {
  margin-bottom: 20px;
  display: flex;
  justify-content: flex-start;
}

.back-btn {
  padding: 8px 16px;
  background-color: #607d8b;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s;
}

.back-btn:hover {
  background-color: #78909c;
}

.edit-form {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
  padding: 30px;
  width: 100%;
}

.input-group {
  margin-bottom: 20px;
}

.input-group label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
  color: #333;
}

.input-field {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 1rem;
}

.textarea-field {
  min-height: 200px;
  resize: vertical;
}

.submit-btn {
  padding: 12px 25px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1.1rem;
  transition: background-color 0.3s;
}

.submit-btn:hover {
  background-color: #45a049;
}
</style> 