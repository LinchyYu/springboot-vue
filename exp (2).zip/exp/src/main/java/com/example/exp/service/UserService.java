package com.example.exp.service;
import com.example.exp.domain.user;
import java.util.List;
public interface UserService {
    List<user> getAllUsers();
    user findUserById(int id);
    user addUser(user newUser);
    user updateUser(user updatedUser);
    user delUser(int id);
    user findByUsername(String username);
}
