package com.example.exp.mapper;

import com.example.exp.domain.post;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;
import org.apache.ibatis.annotations.Options;

@Mapper
public interface PostMapper {
    List<post> findAllPosts();
    post findPostById(int id);

    @Options(useGeneratedKeys = true, keyProperty = "id")
    int addPost(post newPost);
    int updatePost(post updatedPost);
    int delPost(int id);
    int addKudos(int id);
}
