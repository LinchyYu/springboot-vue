package com.example.exp.domain;

public class post {
    private int id;
    private String title;
    private String content;
    private int authorId;
    private String nickname;
    private String create_time;
    private String last_reply_time;
    private int likes;
    private int comments;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }

    public int getAuthorId() {
        return authorId;
    }
    public void setAuthorId(int authorId) {
        this.authorId = authorId;
    }

    public String getNickname() {
        return nickname;
    }
    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getCreate_time() {
        return create_time;
    }
    public void setCreate_time(String create_time) {
        this.create_time = create_time;
    }

    public String getLast_reply_time() {
        return last_reply_time;
    }
    public void setLast_reply_time(String last_reply_time) {
        this.last_reply_time = last_reply_time;
    }

    public int getLikes() {
        return likes;
    }
    public void setLikes(int likes) {
        this.likes = likes;
    }

    public int getComments() {
        return comments;
    }
    public void setComments(int comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "post{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", authorId=" + authorId +
                ", nickname='" + nickname + '\'' +
                ", create_time='" + create_time + '\'' +
                ", last_reply_time='" + last_reply_time + '\'' +
                ", likes=" + likes +
                ", comments=" + comments +
                '}';
    }

}
