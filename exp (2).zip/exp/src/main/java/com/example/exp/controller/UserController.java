package com.example.exp.controller;
import com.example.exp.domain.user;
import com.example.exp.domain.LoginRequest;
import com.example.exp.domain.LoginResponse;
import com.example.exp.service.UserService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import java.util.List;
@RestController
@RequestMapping("/users")
public class UserController {
    private final UserService userService;
    public UserController(UserService userService) {
        this.userService = userService;
    }
    @GetMapping("/get-allusers")
    public List<user> getAllUsers() {
        return userService.getAllUsers();
    }
    @GetMapping("/get/{id}")
    public user getUserById(@PathVariable int id) {
//        System.out.println(userService.findUserById(id).toString());
        return userService.findUserById(id);
    }
    @PostMapping("/add-user")
    public user addUser(@RequestBody user newUser) {
//        System.out.println("Heeeeeeeeeeeeeeeeeeeeeello World");
//        System.out.println(newUser.toString());
//        System.out.println(userService.addUser(newUser).toString());
        return userService.addUser(newUser);
    }
    @PostMapping("/login")
    public LoginResponse login(@RequestBody LoginRequest loginRequest) {
        user foundUser = userService.findUserById(loginRequest.getUserId()); // 根据 userId 查找用户

        if (foundUser != null && foundUser.getPassword().equals(loginRequest.getPassword())) {
            // 登录成功，返回模拟的 token 和用户信息
            String token = "mock_token_for_" + foundUser.getId(); // token 中包含用户 ID
            return new LoginResponse(200, "登录成功", token, String.valueOf(foundUser.getId()), foundUser.getNickname()); // 将用户 ID 作为 username 返回，并添加 nickname
        } else {
            // 登录失败
            return new LoginResponse(401, "用户ID或密码错误", null, null, null);
        }
    }
    @DeleteMapping("/del-user/{id}")
    public user delUser(@PathVariable int id) {
//        System.out.println("Heeeeeeeeeeeeeeeeeeeeeello World");
//        System.out.println(id);
//        System.out.println(userService.delUser(id).toString());
        return userService.delUser(id);
    }
    @PutMapping("/update-user")
    public user updateUsers(@RequestBody user updateUser) {
        System.out.println(userService.updateUser(updateUser).toString());
        return userService.updateUser(updateUser);
    }
}