package com.example.exp.service;

import com.example.exp.domain.post;
import com.example.exp.domain.user;
import com.example.exp.mapper.PostMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class PostServiceImpl implements PostService {
    private final PostMapper postMapper;
    private final UserService userService;

    @Autowired
    public PostServiceImpl(PostMapper postMapper, UserService userService) {
        this.postMapper = postMapper;
        this.userService = userService;
    }

    @Override
    public List<post> getAllPosts() {
        return postMapper.findAllPosts();
    }

    @Override
    public post findPostById(int id) {
        return postMapper.findPostById(id);
    }

    @Override
    public post addPost(post newPost) {
        // 设置创建时间和最后回复时间
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentTime = sdf.format(new Date());
        newPost.setCreate_time(currentTime);
        newPost.setLast_reply_time(currentTime);

        // 根据 authorId (由前端传入) 获取用户昵称
        user foundUser = userService.findUserById(newPost.getAuthorId());
        if (foundUser != null) {
            newPost.setNickname(foundUser.getNickname());
        } else {
            // 如果找不到用户，可以抛出异常或设置默认昵称
            newPost.setNickname("未知用户"); // 或者抛出 RuntimeException
            System.err.println("User not found for authorId: " + newPost.getAuthorId());
        }

        int rowsAffected = postMapper.addPost(newPost);

        if (rowsAffected > 0) {
            return newPost; 
        } else {
            throw new RuntimeException("Failed to save post");
        }
    }

    @Override
    public post updatePost(post updatedPost) {
        int rowsAffected = postMapper.updatePost(updatedPost);
        if (rowsAffected > 0) {
            return postMapper.findPostById(updatedPost.getId());
        } else {
            throw new RuntimeException("Failed to update post");
        }
    }

    @Override
    public post delPost(int id) {
        post del = postMapper.findPostById(id);
        int rowsAffected = postMapper.delPost(id);
        if (rowsAffected > 0) {
            return del;
        } else {
            throw new RuntimeException("Failed to delete post");
        }
    }

    @Override
    public post addKudos(int id) {
        int rowsAffected = postMapper.addKudos(id);
        if (rowsAffected > 0) {
            return postMapper.findPostById(id);
        } else {
            throw new RuntimeException("Failed to add kudos");
        }
    }
}
