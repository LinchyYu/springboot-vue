package com.example.exp.service;

import com.example.exp.domain.Comment;
import com.example.exp.mapper.CommentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CommentServiceImpl implements CommentService {

    private final CommentMapper commentMapper;

    @Autowired
    public CommentServiceImpl(CommentMapper commentMapper) {
        this.commentMapper = commentMapper;
    }

    @Override
    public Comment addComment(Comment newComment) {
        newComment.setComment_time(String.valueOf(LocalDateTime.now()));
        commentMapper.addComment(newComment);
        return newComment;
    }

    @Override
    public List<Comment> getCommentsByPostId(int postId) {
        return commentMapper.findCommentsByPostId(postId);
    }

    @Override
    public Comment deleteComment(int commentId) {
        Comment comment = commentMapper.findCommentById(commentId);
        if (comment == null) {
            throw new RuntimeException("Comment not found");
        }
        commentMapper.deleteCommentById(commentId);
        return comment;
    }

    @Override
    public Comment updateComment(Comment updatedComment) {
        Comment existingComment = commentMapper.findCommentById(updatedComment.getId());
        if (existingComment == null) {
            throw new RuntimeException("Comment not found");
        }
        existingComment.setComment_content(updatedComment.getComment_content());
        existingComment.setComment_time(String.valueOf(LocalDateTime.now()));
        existingComment.setRes_id(updatedComment.getRes_id());
        existingComment.setNickname(updatedComment.getNickname());
        existingComment.setCom_id(updatedComment.getCom_id());
        existingComment.setMaincom_id(updatedComment.getMaincom_id());
        existingComment.setPost_id(updatedComment.getPost_id());

        commentMapper.updateComment(existingComment);
        return existingComment;
    }

    @Override
    public Comment findCommentById(int id) {
        return commentMapper.findCommentById(id);
    }
} 